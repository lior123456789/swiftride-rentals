import React from 'react';
import { X, Calendar, MapPin, Clock, Car, User, Phone, Mail, CreditCard, FileText } from 'lucide-react';
import { Booking } from '../hooks/useBookings';

interface BookingDetailsModalProps {
  booking: Booking;
  isOpen: boolean;
  onClose: () => void;
}

const BookingDetailsModal: React.FC<BookingDetailsModalProps> = ({ booking, isOpen, onClose }) => {
  if (!isOpen) return null;

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const formatTime = (timeString: string) => {
    return new Date(`2000-01-01T${timeString}`).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  const getStatusColor = (status: Booking['status']) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'confirmed':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'active':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'completed':
        return 'bg-gray-100 text-gray-800 border-gray-200';
      case 'cancelled':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getPaymentStatusColor = (status: Booking['payment_status']) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'down_payment_paid':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'fully_paid':
        return 'bg-green-100 text-green-800 border-green-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Booking Details</h2>
            <p className="text-gray-600">ID: {booking.booking_id}</p>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="p-6">
          {/* Status Badges */}
          <div className="flex flex-wrap gap-3 mb-6">
            <span className={`inline-flex px-3 py-1 text-sm font-medium rounded-full border ${getStatusColor(booking.status)}`}>
              Booking Status: {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
            </span>
            <span className={`inline-flex px-3 py-1 text-sm font-medium rounded-full border ${getPaymentStatusColor(booking.payment_status)}`}>
              Payment: {booking.payment_status.replace('_', ' ').charAt(0).toUpperCase() + booking.payment_status.replace('_', ' ').slice(1)}
            </span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Vehicle Information */}
            <div className="space-y-6">
              <div className="bg-gray-50 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                  <Car className="h-5 w-5 mr-2" />
                  Vehicle Information
                </h3>
                <div className="space-y-4">
                  <img 
                    src={booking.vehicle_image_url} 
                    alt={`${booking.vehicle_make} ${booking.vehicle_model}`}
                    className="w-full h-48 object-cover rounded-lg"
                  />
                  <div className="space-y-2">
                    <p><strong>Vehicle:</strong> {booking.vehicle_make} {booking.vehicle_model} {booking.vehicle_year}</p>
                    <p><strong>Company:</strong> {booking.vehicle_company}</p>
                    <p><strong>Daily Rate:</strong> ${booking.daily_rate.toFixed(2)}</p>
                    <p><strong>Rental Period:</strong> {booking.rental_days} day{booking.rental_days > 1 ? 's' : ''}</p>
                  </div>
                </div>
              </div>

              {/* Customer Information */}
              <div className="bg-gray-50 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                  <User className="h-5 w-5 mr-2" />
                  Customer Information
                </h3>
                <div className="space-y-2">
                  <p><strong>Name:</strong> {booking.customer_first_name} {booking.customer_last_name}</p>
                  <p className="flex items-center">
                    <Mail className="h-4 w-4 mr-2" />
                    {booking.customer_email}
                  </p>
                  <p className="flex items-center">
                    <Phone className="h-4 w-4 mr-2" />
                    {booking.customer_phone}
                  </p>
                  <p><strong>Driver Age:</strong> {booking.driver_age}</p>
                </div>
              </div>
            </div>

            {/* Rental Details */}
            <div className="space-y-6">
              <div className="bg-gray-50 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                  <MapPin className="h-5 w-5 mr-2" />
                  Rental Details
                </h3>
                <div className="space-y-4">
                  <div>
                    <p className="font-medium text-gray-900">Pickup</p>
                    <p className="text-gray-600">{booking.pickup_location}</p>
                    <p className="text-sm text-gray-500 flex items-center mt-1">
                      <Calendar className="h-4 w-4 mr-1" />
                      {formatDate(booking.pickup_date)}
                    </p>
                    <p className="text-sm text-gray-500 flex items-center">
                      <Clock className="h-4 w-4 mr-1" />
                      {formatTime(booking.pickup_time)}
                    </p>
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">Return</p>
                    <p className="text-gray-600">{booking.dropoff_location}</p>
                    <p className="text-sm text-gray-500 flex items-center mt-1">
                      <Calendar className="h-4 w-4 mr-1" />
                      {formatDate(booking.return_date)}
                    </p>
                    <p className="text-sm text-gray-500 flex items-center">
                      <Clock className="h-4 w-4 mr-1" />
                      {formatTime(booking.return_time)}
                    </p>
                  </div>
                </div>
              </div>

              {/* Pricing Breakdown */}
              <div className="bg-gray-50 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                  <CreditCard className="h-5 w-5 mr-2" />
                  Pricing Breakdown
                </h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Vehicle ({booking.rental_days} days)</span>
                    <span>${(booking.daily_rate * booking.rental_days).toFixed(2)}</span>
                  </div>
                  {booking.addon_total > 0 && (
                    <div className="flex justify-between">
                      <span>Add-ons</span>
                      <span>${booking.addon_total.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span>${booking.subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Tax</span>
                    <span>${booking.tax_amount.toFixed(2)}</span>
                  </div>
                  <div className="border-t pt-2 flex justify-between font-semibold text-lg">
                    <span>Total</span>
                    <span>${booking.total_amount.toFixed(2)}</span>
                  </div>
                  {booking.payment_status !== 'pending' && (
                    <div className="flex justify-between text-green-600">
                      <span>Down Payment</span>
                      <span>-${booking.down_payment_amount.toFixed(2)}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Add-ons */}
              {booking.addons.length > 0 && (
                <div className="bg-gray-50 rounded-lg p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Add-ons</h3>
                  <ul className="space-y-1">
                    {booking.addons.map((addon, index) => (
                      <li key={index} className="text-gray-600">• {addon}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>

          {/* Booking Timeline */}
          <div className="mt-8 bg-gray-50 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Booking Timeline</h3>
            <div className="space-y-2 text-sm">
              <p><strong>Created:</strong> {new Date(booking.created_at).toLocaleString()}</p>
              <p><strong>Last Updated:</strong> {new Date(booking.updated_at).toLocaleString()}</p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-gray-200 px-6 py-4 bg-gray-50 rounded-b-lg">
          <div className="flex justify-end">
            <button
              onClick={onClose}
              className="bg-gray-600 hover:bg-gray-700 text-white px-6 py-2 rounded-lg font-medium transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BookingDetailsModal;