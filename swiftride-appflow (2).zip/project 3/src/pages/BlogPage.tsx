import React from 'react';
import { Calendar, User, ArrowRight, Clock } from 'lucide-react';

const BlogPage: React.FC = () => {
  const featuredPost = {
    id: 1,
    title: "Ultimate Road Trip Guide: Best Routes Across America",
    excerpt: "Discover the most scenic and exciting road trip routes across the United States. From coast to coast adventures to hidden gems off the beaten path.",
    image: "https://images.pexels.com/photos/1592384/pexels-photo-1592384.jpeg?auto=compress&cs=tinysrgb&w=800",
    author: "Sarah Johnson",
    date: "March 15, 2024",
    readTime: "8 min read",
    category: "Travel Guides"
  };

  const blogPosts = [
    {
      id: 2,
      title: "5 Essential Car Rental Tips for First-Time Renters",
      excerpt: "New to car rentals? Here are the essential tips you need to know to make your first rental experience smooth and stress-free.",
      image: "https://images.pexels.com/photos/116675/pexels-photo-116675.jpeg?auto=compress&cs=tinysrgb&w=400",
      author: "Mike Chen",
      date: "March 12, 2024",
      readTime: "5 min read",
      category: "Car Rental Tips"
    },
    {
      id: 3,
      title: "Best Cars for Family Road Trips in 2024",
      excerpt: "Planning a family vacation? Discover the most comfortable and spacious vehicles perfect for your next family adventure.",
      image: "https://images.pexels.com/photos/1166990/pexels-photo-1166990.jpeg?auto=compress&cs=tinysrgb&w=400",
      author: "Emily Rodriguez",
      date: "March 10, 2024",
      readTime: "6 min read",
      category: "Vehicle Reviews"
    },
    {
      id: 4,
      title: "Hidden Gems: 10 Must-Visit Destinations in California",
      excerpt: "Explore California's best-kept secrets with our guide to hidden gems that are perfect for your next rental car adventure.",
      image: "https://images.pexels.com/photos/3729464/pexels-photo-3729464.jpeg?auto=compress&cs=tinysrgb&w=400",
      author: "David Park",
      date: "March 8, 2024",
      readTime: "7 min read",
      category: "Travel Guides"
    },
    {
      id: 5,
      title: "Electric vs Gas: Which Rental Car is Right for You?",
      excerpt: "Compare the pros and cons of electric and gas rental cars to help you make the best choice for your next trip.",
      image: "https://images.pexels.com/photos/1719648/pexels-photo-1719648.jpeg?auto=compress&cs=tinysrgb&w=400",
      author: "Lisa Wang",
      date: "March 5, 2024",
      readTime: "4 min read",
      category: "Car Rental Tips"
    },
    {
      id: 6,
      title: "Business Travel Made Easy: Executive Car Rental Guide",
      excerpt: "Maximize your business travel efficiency with our comprehensive guide to executive car rentals and professional travel tips.",
      image: "https://images.pexels.com/photos/3802510/pexels-photo-3802510.jpeg?auto=compress&cs=tinysrgb&w=400",
      author: "Robert Kim",
      date: "March 3, 2024",
      readTime: "6 min read",
      category: "Business Travel"
    },
    {
      id: 7,
      title: "Winter Driving Safety: Essential Tips for Cold Weather",
      excerpt: "Stay safe on winter roads with our comprehensive guide to cold weather driving and vehicle preparation tips.",
      image: "https://images.pexels.com/photos/1592384/pexels-photo-1592384.jpeg?auto=compress&cs=tinysrgb&w=400",
      author: "Jennifer Lee",
      date: "March 1, 2024",
      readTime: "5 min read",
      category: "Safety Tips"
    }
  ];

  const categories = [
    "All Posts",
    "Travel Guides",
    "Car Rental Tips",
    "Vehicle Reviews",
    "Business Travel",
    "Safety Tips"
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <section className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">SwiftRide Blog</h1>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Travel tips, car rental guides, and destination inspiration to make your journey unforgettable
            </p>
          </div>
        </div>
      </section>

      {/* Featured Post */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-lg shadow-lg overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2">
              <div className="relative">
                <img 
                  src={featuredPost.image} 
                  alt={featuredPost.title}
                  className="w-full h-64 lg:h-full object-cover"
                />
                <div className="absolute top-4 left-4">
                  <span className="bg-blue-600 text-white px-3 py-1 rounded-full text-sm font-medium">
                    Featured
                  </span>
                </div>
              </div>
              <div className="p-8 flex flex-col justify-center">
                <div className="mb-4">
                  <span className="text-blue-600 font-medium text-sm">{featuredPost.category}</span>
                </div>
                <h2 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-4">
                  {featuredPost.title}
                </h2>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  {featuredPost.excerpt}
                </p>
                <div className="flex items-center text-sm text-gray-500 mb-6">
                  <User className="h-4 w-4 mr-2" />
                  <span className="mr-4">{featuredPost.author}</span>
                  <Calendar className="h-4 w-4 mr-2" />
                  <span className="mr-4">{featuredPost.date}</span>
                  <Clock className="h-4 w-4 mr-2" />
                  <span>{featuredPost.readTime}</span>
                </div>
                <button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors duration-200 flex items-center w-fit">
                  Read More
                  <ArrowRight className="h-5 w-5 ml-2" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap gap-2 justify-center">
            {categories.map((category, index) => (
              <button
                key={index}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors duration-200 ${
                  index === 0
                    ? 'bg-blue-600 text-white'
                    : 'bg-white text-gray-700 hover:bg-gray-100'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Blog Posts Grid */}
      <section className="pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogPosts.map((post) => (
              <article key={post.id} className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-200">
                <img 
                  src={post.image} 
                  alt={post.title}
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <div className="mb-3">
                    <span className="text-blue-600 font-medium text-sm">{post.category}</span>
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3 line-clamp-2">
                    {post.title}
                  </h3>
                  <p className="text-gray-600 mb-4 line-clamp-3">
                    {post.excerpt}
                  </p>
                  <div className="flex items-center text-sm text-gray-500 mb-4">
                    <User className="h-4 w-4 mr-1" />
                    <span className="mr-3">{post.author}</span>
                    <Calendar className="h-4 w-4 mr-1" />
                    <span className="mr-3">{post.date}</span>
                    <Clock className="h-4 w-4 mr-1" />
                    <span>{post.readTime}</span>
                  </div>
                  <button className="text-blue-600 hover:text-blue-700 font-medium flex items-center transition-colors duration-200">
                    Read More
                    <ArrowRight className="h-4 w-4 ml-1" />
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter Signup */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">Stay Updated</h2>
          <p className="text-xl opacity-90 mb-8 max-w-2xl mx-auto">
            Subscribe to our newsletter for the latest travel tips, car rental guides, and exclusive offers
          </p>
          <div className="max-w-md mx-auto flex">
            <input
              type="email"
              placeholder="Enter your email"
              className="flex-1 px-4 py-3 rounded-l-lg text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-300"
            />
            <button className="bg-orange-500 hover:bg-orange-600 text-white px-6 py-3 rounded-r-lg font-semibold transition-colors duration-200">
              Subscribe
            </button>
          </div>
          <p className="text-sm opacity-75 mt-4">
            No spam, unsubscribe at any time
          </p>
        </div>
      </section>
    </div>
  );
};

export default BlogPage;