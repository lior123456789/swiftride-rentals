interface BookingDetails {
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  vehicle: string;
  pickupLocation: string;
  dropoffLocation: string;
  pickupDate: string;
  pickupTime: string;
  returnDate: string;
  returnTime: string;
  driverAge: string;
  addons: string[];
  totalCost: number;
  bookingId: string;
}

export const sendBookingToWhatsApp = (bookingDetails: BookingDetails) => {
  const phoneNumber = '15147940471'; // Lior's phone number (without + sign for WhatsApp API)
  
  const message = `🚗 NEW CAR RENTAL BOOKING 🚗

📋 BOOKING DETAILS:
• Booking ID: ${bookingDetails.bookingId}
• Vehicle: ${bookingDetails.vehicle}

👤 CUSTOMER INFO:
• Name: ${bookingDetails.customerName}
• Email: ${bookingDetails.customerEmail}
• Phone: ${bookingDetails.customerPhone}
• Driver Age: ${bookingDetails.driverAge}

📍 LOCATIONS:
• Pickup: ${bookingDetails.pickupLocation}
• Drop-off: ${bookingDetails.dropoffLocation}

📅 DATES & TIMES:
• Pickup: ${bookingDetails.pickupDate} at ${bookingDetails.pickupTime}
• Return: ${bookingDetails.returnDate} at ${bookingDetails.returnTime}

💰 PRICING:
• Total Cost: $${bookingDetails.totalCost.toFixed(2)}
• Down Payment: C$200.00 (Already Paid)

🛡️ ADD-ONS:
${bookingDetails.addons.length > 0 ? bookingDetails.addons.map(addon => `• ${addon}`).join('\n') : '• None selected'}

⏰ Booking submitted at: ${new Date().toLocaleString()}

---
SwiftRide Rentals - New Booking Alert`;

  const encodedMessage = encodeURIComponent(message);
  const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodedMessage}`;
  
  // Open WhatsApp in a new window/tab
  window.open(whatsappUrl, '_blank');
};

export const generateBookingId = (): string => {
  const timestamp = Date.now().toString();
  const random = Math.random().toString(36).substring(2, 8).toUpperCase();
  return `SR-${timestamp.slice(-6)}-${random}`;
};