import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../components/AuthProvider';

export interface Booking {
  id: string;
  booking_id: string;
  user_id: string;
  
  // Vehicle Information
  vehicle_make: string;
  vehicle_model: string;
  vehicle_year: number;
  vehicle_image_url: string;
  vehicle_company: string;
  
  // Customer Information
  customer_first_name: string;
  customer_last_name: string;
  customer_email: string;
  customer_phone: string;
  driver_age: string;
  
  // Rental Details
  pickup_location: string;
  dropoff_location: string;
  pickup_date: string;
  pickup_time: string;
  return_date: string;
  return_time: string;
  
  // Pricing
  daily_rate: number;
  rental_days: number;
  subtotal: number;
  tax_amount: number;
  total_amount: number;
  
  // Add-ons
  addons: string[];
  addon_total: number;
  
  // Status and Payment
  status: 'pending' | 'confirmed' | 'active' | 'completed' | 'cancelled';
  payment_status: 'pending' | 'down_payment_paid' | 'fully_paid';
  down_payment_amount: number;
  
  // Timestamps
  created_at: string;
  updated_at: string;
}

export const useBookings = () => {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  const fetchBookings = async () => {
    if (!user) {
      setBookings([]);
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setError(null);

      const { data, error: fetchError } = await supabase
        .from('bookings')
        .select('*')
        .eq('user_id', user.id)
        .is('deleted_at', null)
        .order('created_at', { ascending: false });

      if (fetchError) {
        throw fetchError;
      }

      setBookings(data || []);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to fetch bookings';
      setError(errorMessage);
      console.error('Error fetching bookings:', err);
    } finally {
      setLoading(false);
    }
  };

  const createBooking = async (bookingData: Omit<Booking, 'id' | 'user_id' | 'created_at' | 'updated_at'>) => {
    if (!user) {
      throw new Error('User must be authenticated to create booking');
    }

    try {
      const { data, error: insertError } = await supabase
        .from('bookings')
        .insert({
          ...bookingData,
          user_id: user.id
        })
        .select()
        .single();

      if (insertError) {
        throw insertError;
      }

      // Refresh bookings list
      await fetchBookings();
      
      return data;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to create booking';
      setError(errorMessage);
      console.error('Error creating booking:', err);
      throw err;
    }
  };

  const updateBookingStatus = async (bookingId: string, status: Booking['status'], paymentStatus?: Booking['payment_status']) => {
    try {
      const updateData: any = { status };
      if (paymentStatus) {
        updateData.payment_status = paymentStatus;
      }

      const { error: updateError } = await supabase
        .from('bookings')
        .update(updateData)
        .eq('id', bookingId)
        .eq('user_id', user?.id);

      if (updateError) {
        throw updateError;
      }

      // Refresh bookings list
      await fetchBookings();
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to update booking';
      setError(errorMessage);
      console.error('Error updating booking:', err);
      throw err;
    }
  };

  useEffect(() => {
    fetchBookings();
  }, [user]);

  return {
    bookings,
    loading,
    error,
    createBooking,
    updateBookingStatus,
    refetch: fetchBookings
  };
};