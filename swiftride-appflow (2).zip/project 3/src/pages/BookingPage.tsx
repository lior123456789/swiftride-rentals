import React, { useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Calendar, MapPin, Users, Shield, Navigation, Baby, CheckCircle } from 'lucide-react';
import { cars } from '../data/cars';
import { getMainDownPaymentProduct } from '../stripe-config';
import LocationAutocomplete from '../components/LocationAutocomplete';
import TimeInput from '../components/TimeInput';
import StripeProductCard from '../components/StripeProductCard';
import { sendBookingToWhatsApp, generateBookingId } from '../utils/whatsapp';
import { useBookings } from '../hooks/useBookings';
import { useAuth } from '../components/AuthProvider';

const BookingPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { createBooking } = useBookings();
  
  const selectedCarId = searchParams.get('car');
  const selectedCar = cars.find(car => car.id === selectedCarId) || cars[0];

  const [currentStep, setCurrentStep] = useState(1);
  const [bookingSubmitted, setBookingSubmitted] = useState(false);
  const [bookingId, setBookingId] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Get the main down payment product
  const downPaymentProduct = getMainDownPaymentProduct();
  
  const [formData, setFormData] = useState({
    pickupLocation: '',
    dropoffLocation: '',
    pickupDate: '',
    pickupTime: '',
    returnDate: '',
    returnTime: '',
    driverAge: '',
    firstName: '',
    lastName: '',
    email: user?.email || '',
    phone: '',
    addons: {
      gps: false,
      babySeat: false,
      insurance: false,
      additionalDriver: false
    }
  });

  const addons = [
    { id: 'gps', name: 'GPS Navigation', price: 8, icon: <Navigation className="h-5 w-5" /> },
    { id: 'babySeat', name: 'Baby Seat', price: 12, icon: <Baby className="h-5 w-5" /> },
    { id: 'insurance', name: 'Premium Insurance', price: 15, icon: <Shield className="h-5 w-5" /> },
    { id: 'additionalDriver', name: 'Additional Driver', price: 10, icon: <Users className="h-5 w-5" /> }
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleLocationChange = (field: 'pickupLocation' | 'dropoffLocation', value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleTimeChange = (field: 'pickupTime' | 'returnTime', value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleAddonChange = (addonId: string) => {
    setFormData(prev => ({
      ...prev,
      addons: {
        ...prev.addons,
        [addonId]: !prev.addons[addonId as keyof typeof prev.addons]
      }
    }));
  };

  const calculateDays = () => {
    if (!formData.pickupDate || !formData.returnDate) return 1;
    const pickup = new Date(formData.pickupDate);
    const returnDate = new Date(formData.returnDate);
    const diffTime = Math.abs(returnDate.getTime() - pickup.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays || 1;
  };

  const calculateTotal = () => {
    const days = calculateDays();
    const carTotal = selectedCar.pricePerDay * days;
    const addonTotal = addons.reduce((total, addon) => {
      return total + (formData.addons[addon.id as keyof typeof formData.addons] ? addon.price * days : 0);
    }, 0);
    const subtotal = carTotal + addonTotal;
    const tax = subtotal * 0.08; // 8% tax
    return {
      days,
      carTotal,
      addonTotal,
      subtotal,
      tax,
      total: subtotal + tax
    };
  };

  const pricing = calculateTotal();

  const validateStep = (step: number) => {
    switch (step) {
      case 1:
        return formData.pickupLocation && formData.dropoffLocation && 
               formData.pickupDate && formData.pickupTime && 
               formData.returnDate && formData.returnTime && formData.driverAge;
      case 2:
        return formData.firstName && formData.lastName && formData.email && formData.phone;
      case 3:
        return true; // Add-ons are optional
      default:
        return false;
    }
  };

  const handleNextStep = () => {
    if (validateStep(currentStep)) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handlePreviousStep = () => {
    setCurrentStep(prev => prev - 1);
  };

  const handleSubmitBooking = async () => {
    if (!user) {
      navigate('/login');
      return;
    }

    setIsSubmitting(true);
    
    try {
      // Generate booking ID
      const newBookingId = generateBookingId();
      setBookingId(newBookingId);

      // Get selected addons
      const selectedAddons = addons
        .filter(addon => formData.addons[addon.id as keyof typeof formData.addons])
        .map(addon => addon.name);

      // Create booking in database
      const bookingData = {
        booking_id: newBookingId,
        vehicle_make: selectedCar.make,
        vehicle_model: selectedCar.model,
        vehicle_year: selectedCar.year,
        vehicle_image_url: selectedCar.imageUrl,
        vehicle_company: selectedCar.company,
        customer_first_name: formData.firstName,
        customer_last_name: formData.lastName,
        customer_email: formData.email,
        customer_phone: formData.phone,
        driver_age: formData.driverAge,
        pickup_location: formData.pickupLocation,
        dropoff_location: formData.dropoffLocation,
        pickup_date: formData.pickupDate,
        pickup_time: formData.pickupTime,
        return_date: formData.returnDate,
        return_time: formData.returnTime,
        daily_rate: selectedCar.pricePerDay,
        rental_days: pricing.days,
        subtotal: pricing.subtotal,
        tax_amount: pricing.tax,
        total_amount: pricing.total,
        addons: selectedAddons,
        addon_total: pricing.addonTotal,
        status: 'pending' as const,
        payment_status: 'pending' as const,
        down_payment_amount: downPaymentProduct.price
      };

      await createBooking(bookingData);

      // Prepare booking details for WhatsApp
      const whatsappDetails = {
        customerName: `${formData.firstName} ${formData.lastName}`,
        customerEmail: formData.email,
        customerPhone: formData.phone,
        vehicle: `${selectedCar.make} ${selectedCar.model} ${selectedCar.year}`,
        pickupLocation: formData.pickupLocation,
        dropoffLocation: formData.dropoffLocation,
        pickupDate: formData.pickupDate,
        pickupTime: formData.pickupTime,
        returnDate: formData.returnDate,
        returnTime: formData.returnTime,
        driverAge: formData.driverAge,
        addons: selectedAddons,
        totalCost: pricing.total,
        bookingId: newBookingId
      };

      // Send booking details to WhatsApp
      sendBookingToWhatsApp(whatsappDetails);

      // Mark booking as submitted
      setBookingSubmitted(true);
      setCurrentStep(4); // Move to payment step
    } catch (error) {
      console.error('Error creating booking:', error);
      alert('Failed to create booking. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const steps = [
    { number: 1, title: 'Rental Details', description: 'Dates, locations, and preferences' },
    { number: 2, title: 'Personal Info', description: 'Your contact information' },
    { number: 3, title: 'Add-ons & Review', description: 'Optional extras and confirmation' },
    { number: 4, title: 'Payment', description: 'Complete down payment' }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <h1 className="text-3xl font-bold text-gray-900">Complete Your Booking</h1>
          <p className="text-gray-600 mt-2">Fill in the details to reserve your vehicle</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Form */}
          <div className="lg:col-span-2 space-y-6">
            {/* Progress Steps */}
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex items-center justify-between">
                {steps.map((step, index) => (
                  <div key={step.number} className="flex items-center">
                    <div className={`flex items-center justify-center w-10 h-10 rounded-full border-2 ${
                      currentStep >= step.number 
                        ? 'bg-blue-600 border-blue-600 text-white' 
                        : 'border-gray-300 text-gray-500'
                    }`}>
                      {currentStep > step.number ? (
                        <CheckCircle className="h-6 w-6" />
                      ) : (
                        step.number
                      )}
                    </div>
                    <div className="ml-3 hidden sm:block">
                      <p className={`text-sm font-medium ${
                        currentStep >= step.number ? 'text-blue-600' : 'text-gray-500'
                      }`}>
                        {step.title}
                      </p>
                      <p className="text-xs text-gray-500">{step.description}</p>
                    </div>
                    {index < steps.length - 1 && (
                      <div className={`hidden sm:block w-16 h-0.5 ml-4 ${
                        currentStep > step.number ? 'bg-blue-600' : 'bg-gray-300'
                      }`} />
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Selected Vehicle */}
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Selected Vehicle</h2>
              <div className="flex flex-col sm:flex-row gap-4">
                <img 
                  src={selectedCar.imageUrl} 
                  alt={`${selectedCar.make} ${selectedCar.model}`}
                  className="w-full sm:w-48 h-32 object-cover rounded-lg"
                />
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-gray-900">{selectedCar.make} {selectedCar.model}</h3>
                  <p className="text-gray-600">{selectedCar.year} • {selectedCar.company}</p>
                  <div className="flex items-center gap-4 mt-2 text-sm text-gray-600">
                    <span>{selectedCar.passengers} passengers</span>
                    <span>{selectedCar.luggage} bags</span>
                    <span>{selectedCar.transmission}</span>
                  </div>
                  <div className="mt-2">
                    <span className="text-2xl font-bold text-blue-600">${selectedCar.pricePerDay}</span>
                    <span className="text-gray-600">/day</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Step Content */}
            <div className="bg-white p-6 rounded-lg shadow-sm">
              {currentStep === 1 && (
                <div>
                  <h2 className="text-xl font-semibold text-gray-900 mb-4">Rental Details</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Pick-up Location
                      </label>
                      <LocationAutocomplete
                        value={formData.pickupLocation}
                        onChange={(value) => handleLocationChange('pickupLocation', value)}
                        placeholder="Enter city or airport"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Drop-off Location
                      </label>
                      <LocationAutocomplete
                        value={formData.dropoffLocation}
                        onChange={(value) => handleLocationChange('dropoffLocation', value)}
                        placeholder="Enter city or airport"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        <Calendar className="inline h-4 w-4 mr-1" />
                        Pick-up Date
                      </label>
                      <input
                        type="date"
                        name="pickupDate"
                        value={formData.pickupDate}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                      />
                    </div>
                    <div>
                      <TimeInput
                        value={formData.pickupTime}
                        onChange={(value) => handleTimeChange('pickupTime', value)}
                        name="pickupTime"
                        label="Pick-up Time"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        <Calendar className="inline h-4 w-4 mr-1" />
                        Return Date
                      </label>
                      <input
                        type="date"
                        name="returnDate"
                        value={formData.returnDate}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                      />
                    </div>
                    <div>
                      <TimeInput
                        value={formData.returnTime}
                        onChange={(value) => handleTimeChange('returnTime', value)}
                        name="returnTime"
                        label="Return Time"
                        required
                      />
                    </div>
                  </div>
                  <div className="mt-6">
                    <label className="block text-sm font-medium text-gray-700 mb-2">Driver Age</label>
                    <select
                      name="driverAge"
                      value={formData.driverAge}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    >
                      <option value="">Select age range</option>
                      <option value="21-24">21-24 years</option>
                      <option value="25-29">25-29 years</option>
                      <option value="30-64">30-64 years</option>
                      <option value="65+">65+ years</option>
                    </select>
                  </div>
                </div>
              )}

              {currentStep === 2 && (
                <div>
                  <h2 className="text-xl font-semibold text-gray-900 mb-4">Personal Information</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">First Name</label>
                      <input
                        type="text"
                        name="firstName"
                        value={formData.firstName}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Last Name</label>
                      <input
                        type="text"
                        name="lastName"
                        value={formData.lastName}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                      <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                      />
                    </div>
                  </div>
                </div>
              )}

              {currentStep === 3 && (
                <div>
                  <h2 className="text-xl font-semibold text-gray-900 mb-4">Add-ons & Review</h2>
                  
                  {/* Add-ons */}
                  <div className="mb-8">
                    <h3 className="text-lg font-medium text-gray-900 mb-4">Optional Add-ons</h3>
                    <div className="space-y-4">
                      {addons.map((addon) => (
                        <div key={addon.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                          <div className="flex items-center">
                            <input
                              type="checkbox"
                              id={addon.id}
                              checked={formData.addons[addon.id as keyof typeof formData.addons]}
                              onChange={() => handleAddonChange(addon.id)}
                              className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                            />
                            <label htmlFor={addon.id} className="ml-3 flex items-center">
                              {addon.icon}
                              <span className="ml-2 text-sm font-medium text-gray-900">{addon.name}</span>
                            </label>
                          </div>
                          <span className="text-sm font-medium text-gray-900">${addon.price}/day</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Booking Summary */}
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="text-lg font-medium text-gray-900 mb-4">Booking Summary</h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>Customer:</span>
                        <span>{formData.firstName} {formData.lastName}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Email:</span>
                        <span>{formData.email}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Phone:</span>
                        <span>{formData.phone}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Vehicle:</span>
                        <span>{selectedCar.make} {selectedCar.model}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Pickup:</span>
                        <span>{formData.pickupLocation}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Return:</span>
                        <span>{formData.dropoffLocation}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Dates:</span>
                        <span>{formData.pickupDate} to {formData.returnDate}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Times:</span>
                        <span>{formData.pickupTime} to {formData.returnTime}</span>
                      </div>
                      <div className="flex justify-between font-medium text-base pt-2 border-t">
                        <span>Total Cost:</span>
                        <span>${pricing.total.toFixed(2)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-6">
                    <button
                      onClick={handleSubmitBooking}
                      disabled={isSubmitting}
                      className="w-full bg-green-600 hover:bg-green-700 disabled:bg-gray-400 text-white font-semibold py-3 px-6 rounded-lg transition-colors duration-200 flex items-center justify-center"
                    >
                      {isSubmitting ? (
                        <>
                          <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                          Creating Booking...
                        </>
                      ) : (
                        'Submit Booking & Send to WhatsApp'
                      )}
                    </button>
                  </div>
                </div>
              )}

              {currentStep === 4 && (
                <div>
                  <h2 className="text-xl font-semibold text-gray-900 mb-4">Complete Your Booking</h2>
                  
                  {bookingSubmitted ? (
                    <div>
                      <div className="bg-green-50 border border-green-200 rounded-lg p-6 mb-6">
                        <div className="flex items-center">
                          <CheckCircle className="h-6 w-6 text-green-600 mr-3" />
                          <div>
                            <h3 className="text-lg font-semibold text-green-900 mb-2">
                              Booking Created Successfully!
                            </h3>
                            <p className="text-green-800 mb-2">
                              <strong>Booking ID:</strong> {bookingId}
                            </p>
                            <p className="text-green-800">
                              Your booking has been saved and details sent to our team via WhatsApp. 
                              Complete the down payment to secure your reservation.
                            </p>
                          </div>
                        </div>
                      </div>
                      
                      <div className="max-w-md mx-auto">
                        <StripeProductCard 
                          product={downPaymentProduct} 
                          className="!shadow-none !border-blue-200"
                          successUrl={`${window.location.origin}/success?redirect=${encodeURIComponent('/account?tab=bookings')}`}
                          cancelUrl={window.location.href}
                        />
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <p className="text-gray-600">Please complete the previous steps first.</p>
                    </div>
                  )}
                </div>
              )}

              {/* Navigation Buttons */}
              {currentStep < 4 && (
                <div className="flex justify-between mt-8">
                  <button
                    onClick={handlePreviousStep}
                    disabled={currentStep === 1}
                    className="bg-gray-100 hover:bg-gray-200 disabled:bg-gray-50 disabled:text-gray-400 text-gray-700 px-6 py-2 rounded-lg font-semibold transition-colors duration-200"
                  >
                    Previous
                  </button>
                  
                  {currentStep < 3 ? (
                    <button
                      onClick={handleNextStep}
                      disabled={!validateStep(currentStep)}
                      className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white px-6 py-2 rounded-lg font-semibold transition-colors duration-200"
                    >
                      Next Step
                    </button>
                  ) : null}
                </div>
              )}
            </div>
          </div>

          {/* Booking Summary Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white p-6 rounded-lg shadow-sm sticky top-8">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Booking Summary</h2>
              
              <div className="space-y-3 mb-6">
                <div className="flex justify-between">
                  <span className="text-gray-600">Vehicle ({pricing.days} days)</span>
                  <span className="font-medium">${pricing.carTotal.toFixed(2)}</span>
                </div>
                {pricing.addonTotal > 0 && (
                  <div className="flex justify-between">
                    <span className="text-gray-600">Add-ons</span>
                    <span className="font-medium">${pricing.addonTotal.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-gray-600">Subtotal</span>
                  <span className="font-medium">${pricing.subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Tax (8%)</span>
                  <span className="font-medium">${pricing.tax.toFixed(2)}</span>
                </div>
                <div className="border-t pt-3">
                  <div className="flex justify-between">
                    <span className="text-lg font-semibold text-gray-900">Total</span>
                    <span className="text-lg font-semibold text-blue-600">${pricing.total.toFixed(2)}</span>
                  </div>
                </div>
              </div>

              {/* Progress Indicator */}
              <div className="mb-4">
                <div className="flex justify-between text-sm text-gray-600 mb-2">
                  <span>Progress</span>
                  <span>{currentStep}/4 steps</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${(currentStep / 4) * 100}%` }}
                  ></div>
                </div>
              </div>

              {bookingSubmitted && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-4">
                  <div className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
                    <div>
                      <p className="text-sm font-medium text-green-900">Booking Created</p>
                      <p className="text-xs text-green-700">ID: {bookingId}</p>
                    </div>
                  </div>
                </div>
              )}

              <div className="mt-4 text-center text-sm text-gray-600">
                <Shield className="inline h-4 w-4 mr-1" />
                Secure booking with SSL encryption
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BookingPage;