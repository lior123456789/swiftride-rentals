import React from 'react';
import { CreditCard, Loader2, Shield, User } from 'lucide-react';
import { StripeProduct } from '../stripe-config';
import { useStripe } from '../hooks/useStripe';
import { useAuth } from './AuthProvider';
import { useNavigate } from 'react-router-dom';

interface StripeProductCardProps {
  product: StripeProduct;
  className?: string;
  successUrl?: string;
  cancelUrl?: string;
}

const StripeProductCard: React.FC<StripeProductCardProps> = ({ 
  product, 
  className = '',
  successUrl,
  cancelUrl
}) => {
  const { createCheckoutSession, loading, error } = useStripe();
  const { user } = useAuth();
  const navigate = useNavigate();

  const handlePurchase = async () => {
    if (!user) {
      // If user is not logged in, redirect to login with return URL
      const returnUrl = encodeURIComponent(window.location.href);
      navigate(`/login?redirect=${returnUrl}`);
      return;
    }

    await createCheckoutSession({
      priceId: product.priceId,
      mode: product.mode,
      successUrl,
      cancelUrl,
    });
  };

  const formatPrice = (price: number, currency: string) => {
    return new Intl.NumberFormat('en-CA', {
      style: 'currency',
      currency: currency,
    }).format(price);
  };

  return (
    <div className={`bg-white rounded-lg shadow-lg border border-gray-200 p-6 ${className}`}>
      <div className="mb-4">
        <div className="flex items-center mb-2">
          <Shield className="h-5 w-5 text-blue-600 mr-2" />
          <h3 className="text-xl font-semibold text-gray-900">{product.name}</h3>
        </div>
        <p className="text-gray-600 text-sm mb-4">{product.description}</p>
        
        <div className="flex items-baseline mb-4">
          <span className="text-3xl font-bold text-gray-900">
            {formatPrice(product.price, product.currency)}
          </span>
          {product.mode === 'subscription' && (
            <span className="text-gray-600 ml-2">/month</span>
          )}
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4">
          <div className="flex items-start">
            <Shield className="h-4 w-4 text-blue-600 mt-0.5 mr-2 flex-shrink-0" />
            <div className="text-sm text-blue-800">
              <p className="font-medium">Secure Your Rental</p>
              <p>This down payment will be applied to your final rental cost.</p>
            </div>
          </div>
        </div>
      </div>

      {error && (
        <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-md">
          <p className="text-sm text-red-700">{error}</p>
        </div>
      )}

      {!user && (
        <div className="mb-4 p-3 bg-orange-50 border border-orange-200 rounded-md">
          <div className="flex items-center">
            <User className="h-4 w-4 text-orange-600 mr-2" />
            <p className="text-sm text-orange-800">
              You need to sign in or create an account to complete the payment.
            </p>
          </div>
        </div>
      )}

      <button
        onClick={handlePurchase}
        disabled={loading}
        className="w-full flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200"
      >
        {loading ? (
          <>
            <Loader2 className="animate-spin h-4 w-4 mr-2" />
            Processing...
          </>
        ) : !user ? (
          <>
            <User className="h-4 w-4 mr-2" />
            Sign In to Pay
          </>
        ) : (
          <>
            <CreditCard className="h-4 w-4 mr-2" />
            Pay Down Payment
          </>
        )}
      </button>

      <p className="text-xs text-gray-500 mt-2 text-center">
        Secure payment powered by Stripe
      </p>
    </div>
  );
};

export default StripeProductCard;