import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Filter, Grid, List, Users, Luggage, Star, Fuel, User } from 'lucide-react';
import { cars, Car } from '../data/cars';
import { useAuth } from '../components/AuthProvider';

const VehiclesPage: React.FC = () => {
  const [filteredCars, setFilteredCars] = useState<Car[]>(cars);
  const [selectedType, setSelectedType] = useState<string>('all');
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 200]);
  const [selectedCompany, setSelectedCompany] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [sortBy, setSortBy] = useState<string>('price');
  
  const { user } = useAuth();
  const navigate = useNavigate();

  const carTypes = ['all', 'economy', 'compact', 'midsize', 'fullsize', 'suv', 'luxury', 'minivan'];
  const companies = ['all', 'Hertz', 'Enterprise', 'Budget'];

  const filterCars = () => {
    let filtered = cars;

    if (selectedType !== 'all') {
      filtered = filtered.filter(car => car.type === selectedType);
    }

    if (selectedCompany !== 'all') {
      filtered = filtered.filter(car => car.company === selectedCompany);
    }

    filtered = filtered.filter(car => car.pricePerDay >= priceRange[0] && car.pricePerDay <= priceRange[1]);

    // Sort cars
    if (sortBy === 'price') {
      filtered.sort((a, b) => a.pricePerDay - b.pricePerDay);
    } else if (sortBy === 'rating') {
      filtered.sort((a, b) => b.rating - a.rating);
    } else if (sortBy === 'name') {
      filtered.sort((a, b) => `${a.make} ${a.model}`.localeCompare(`${b.make} ${b.model}`));
    }

    setFilteredCars(filtered);
  };

  React.useEffect(() => {
    filterCars();
  }, [selectedType, priceRange, selectedCompany, sortBy]);

  const handleBookNow = (carId: string) => {
    if (!user) {
      // If user is not logged in, redirect to login with return URL
      const returnUrl = encodeURIComponent(`/booking?car=${carId}`);
      navigate(`/login?redirect=${returnUrl}`);
      return;
    }
    
    // If user is logged in, go directly to booking
    navigate(`/booking?car=${carId}`);
  };

  const getBookButtonText = () => {
    if (!user) return 'Sign In to Book';
    return 'Book Now';
  };

  const getBookButtonStyle = () => {
    if (!user) {
      return 'bg-orange-600 hover:bg-orange-700 text-white px-6 py-2 rounded-lg font-semibold transition-colors duration-200 flex items-center';
    }
    return 'bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg font-semibold transition-colors duration-200';
  };

  const CarCard: React.FC<{ car: Car }> = ({ car }) => (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-200">
      <img src={car.imageUrl} alt={`${car.make} ${car.model}`} className="w-full h-48 object-cover" />
      <div className="p-6">
        <div className="flex justify-between items-start mb-2">
          <div>
            <h3 className="text-xl font-semibold text-gray-900">{car.make} {car.model}</h3>
            <p className="text-sm text-gray-600">{car.year} • {car.company}</p>
          </div>
          <div className="flex items-center">
            <Star className="h-4 w-4 text-yellow-400 fill-current" />
            <span className="text-sm text-gray-600 ml-1">{car.rating}</span>
          </div>
        </div>
        
        <div className="flex items-center gap-4 mb-4 text-sm text-gray-600">
          <div className="flex items-center">
            <Users className="h-4 w-4 mr-1" />
            {car.passengers}
          </div>
          <div className="flex items-center">
            <Luggage className="h-4 w-4 mr-1" />
            {car.luggage}
          </div>
          <div className="flex items-center">
            <Fuel className="h-4 w-4 mr-1" />
            {car.fuelType}
          </div>
        </div>

        <div className="flex flex-wrap gap-2 mb-4">
          {car.features.slice(0, 3).map((feature, index) => (
            <span key={index} className="text-xs text-gray-600 bg-gray-100 px-2 py-1 rounded">
              {feature}
            </span>
          ))}
          {car.features.length > 3 && (
            <span className="text-xs text-gray-600 bg-gray-100 px-2 py-1 rounded">
              +{car.features.length - 3} more
            </span>
          )}
        </div>

        <div className="flex justify-between items-center">
          <div>
            <span className="text-2xl font-bold text-gray-900">${car.pricePerDay}</span>
            <span className="text-sm text-gray-600">/day</span>
          </div>
          <button
            onClick={() => handleBookNow(car.id)}
            className={getBookButtonStyle()}
          >
            {!user && <User className="h-4 w-4 mr-2" />}
            {getBookButtonText()}
          </button>
        </div>
      </div>
    </div>
  );

  const CarListItem: React.FC<{ car: Car }> = ({ car }) => (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-200">
      <div className="flex flex-col md:flex-row">
        <img src={car.imageUrl} alt={`${car.make} ${car.model}`} className="w-full md:w-64 h-48 object-cover" />
        <div className="p-6 flex-1">
          <div className="flex justify-between items-start mb-4">
            <div>
              <h3 className="text-xl font-semibold text-gray-900">{car.make} {car.model}</h3>
              <p className="text-sm text-gray-600">{car.year} • {car.company}</p>
              <div className="flex items-center mt-1">
                <Star className="h-4 w-4 text-yellow-400 fill-current" />
                <span className="text-sm text-gray-600 ml-1">{car.rating}</span>
              </div>
            </div>
            <div className="text-right">
              <span className="text-2xl font-bold text-gray-900">${car.pricePerDay}</span>
              <span className="text-sm text-gray-600">/day</span>
            </div>
          </div>
          
          <div className="flex items-center gap-6 mb-4 text-sm text-gray-600">
            <div className="flex items-center">
              <Users className="h-4 w-4 mr-1" />
              {car.passengers} passengers
            </div>
            <div className="flex items-center">
              <Luggage className="h-4 w-4 mr-1" />
              {car.luggage} bags
            </div>
            <div className="flex items-center">
              <Fuel className="h-4 w-4 mr-1" />
              {car.fuelType}
            </div>
            <span className="capitalize">{car.transmission}</span>
          </div>

          <div className="flex flex-wrap gap-2 mb-4">
            {car.features.map((feature, index) => (
              <span key={index} className="text-xs text-gray-600 bg-gray-100 px-2 py-1 rounded">
                {feature}
              </span>
            ))}
          </div>

          <div className="flex justify-end">
            <button
              onClick={() => handleBookNow(car.id)}
              className={getBookButtonStyle()}
            >
              {!user && <User className="h-4 w-4 mr-2" />}
              {getBookButtonText()}
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <h1 className="text-3xl font-bold text-gray-900">Our Vehicle Fleet</h1>
          <p className="text-gray-600 mt-2">Choose from our wide selection of premium vehicles</p>
          {!user && (
            <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-sm text-blue-800">
                <User className="inline h-4 w-4 mr-1" />
                Sign in or create an account to book your rental car
              </p>
            </div>
          )}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filters Sidebar */}
          <div className="lg:w-64 space-y-6">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                <Filter className="h-5 w-5 mr-2" />
                Filters
              </h3>
              
              {/* Vehicle Type */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">Vehicle Type</label>
                <select
                  value={selectedType}
                  onChange={(e) => setSelectedType(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  {carTypes.map(type => (
                    <option key={type} value={type}>
                      {type === 'all' ? 'All Types' : type.charAt(0).toUpperCase() + type.slice(1)}
                    </option>
                  ))}
                </select>
              </div>

              {/* Company */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">Rental Company</label>
                <select
                  value={selectedCompany}
                  onChange={(e) => setSelectedCompany(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  {companies.map(company => (
                    <option key={company} value={company}>
                      {company === 'all' ? 'All Companies' : company}
                    </option>
                  ))}
                </select>
              </div>

              {/* Price Range */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">Price Range</label>
                <div className="flex items-center space-x-2">
                  <input
                    type="number"
                    value={priceRange[0]}
                    onChange={(e) => setPriceRange([parseInt(e.target.value), priceRange[1]])}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Min"
                  />
                  <span>-</span>
                  <input
                    type="number"
                    value={priceRange[1]}
                    onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value)])}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Max"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {/* Controls */}
            <div className="bg-white p-4 rounded-lg shadow-sm mb-6">
              <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-600">
                    Showing {filteredCars.length} of {cars.length} vehicles
                  </span>
                </div>
                
                <div className="flex items-center gap-4">
                  {/* Sort */}
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                    className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="price">Sort by Price</option>
                    <option value="rating">Sort by Rating</option>
                    <option value="name">Sort by Name</option>
                  </select>

                  {/* View Mode */}
                  <div className="flex border border-gray-300 rounded-md">
                    <button
                      onClick={() => setViewMode('grid')}
                      className={`p-2 ${viewMode === 'grid' ? 'bg-blue-600 text-white' : 'text-gray-600'}`}
                    >
                      <Grid className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => setViewMode('list')}
                      className={`p-2 ${viewMode === 'list' ? 'bg-blue-600 text-white' : 'text-gray-600'}`}
                    >
                      <List className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Vehicle Grid/List */}
            {viewMode === 'grid' ? (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {filteredCars.map((car) => (
                  <CarCard key={car.id} car={car} />
                ))}
              </div>
            ) : (
              <div className="space-y-6">
                {filteredCars.map((car) => (
                  <CarListItem key={car.id} car={car} />
                ))}
              </div>
            )}

            {/* No Results */}
            {filteredCars.length === 0 && (
              <div className="text-center py-12">
                <div className="text-gray-400 mb-4">
                  <svg className="h-12 w-12 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">No vehicles found</h3>
                <p className="text-gray-600">Try adjusting your filters to see more results.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default VehiclesPage;