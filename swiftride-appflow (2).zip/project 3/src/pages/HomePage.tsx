import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Calendar, MapPin, Clock, Shield, Headphones, DollarSign, Star, Car } from 'lucide-react';
import LocationAutocomplete from '../components/LocationAutocomplete';

const HomePage: React.FC = () => {
  const [pickupLocation, setPickupLocation] = useState('');
  const [dropoffLocation, setDropoffLocation] = useState('');
  const [pickupDate, setPickupDate] = useState('');
  const [returnDate, setReturnDate] = useState('');

  const benefits = [
    {
      icon: <DollarSign className="h-8 w-8 text-blue-600" />,
      title: 'Affordable Rates',
      description: 'Competitive prices with no hidden fees. Best value for your money.'
    },
    {
      icon: <Shield className="h-8 w-8 text-blue-600" />,
      title: 'Clean & Maintained',
      description: 'All vehicles are professionally cleaned and regularly maintained.'
    },
    {
      icon: <Headphones className="h-8 w-8 text-blue-600" />,
      title: '24/7 Support',
      description: 'Round-the-clock customer support for any assistance you need.'
    }
  ];

  const testimonials = [
    {
      name: 'Sarah Johnson',
      rating: 5,
      comment: 'Excellent service! The car was clean, reliable, and the booking process was seamless.',
      location: 'New York, NY'
    },
    {
      name: 'Mike Chen',
      rating: 5,
      comment: 'Great prices and fantastic customer service. Will definitely rent again!',
      location: 'Los Angeles, CA'
    },
    {
      name: 'Emily Davis',
      rating: 5,
      comment: 'Perfect for my business trip. Professional service and quality vehicles.',
      location: 'Chicago, IL'
    }
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-blue-900 to-blue-700 text-white">
        <div className="absolute inset-0 bg-black opacity-30"></div>
        <div 
          className="relative min-h-screen flex items-center justify-center bg-cover bg-center"
          style={{
            backgroundImage: "url('https://images.pexels.com/photos/1592384/pexels-photo-1592384.jpeg?auto=compress&cs=tinysrgb&w=1920')"
          }}
        >
          <div className="absolute inset-0 bg-blue-900 opacity-75"></div>
          <div className="relative z-10 text-center max-w-4xl mx-auto px-4">
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              Rent Your Ride in Minutes
            </h1>
            <p className="text-xl md:text-2xl mb-8 opacity-90">
              Choose from our premium fleet of vehicles and hit the road with confidence
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/vehicles"
                className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-3 rounded-lg text-lg font-semibold transition-colors duration-200"
              >
                Book Now
              </Link>
              <Link
                to="/vehicles"
                className="bg-transparent border-2 border-white hover:bg-white hover:text-blue-900 text-white px-8 py-3 rounded-lg text-lg font-semibold transition-all duration-200"
              >
                View Fleet
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Booking Form */}
      <section className="py-12 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-lg shadow-lg p-8">
            <h2 className="text-3xl font-bold text-center mb-8 text-gray-900">Quick Booking</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Pick-up Location
                </label>
                <LocationAutocomplete
                  value={pickupLocation}
                  onChange={setPickupLocation}
                  placeholder="Enter city or airport"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Drop-off Location
                </label>
                <LocationAutocomplete
                  value={dropoffLocation}
                  onChange={setDropoffLocation}
                  placeholder="Enter city or airport"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <Calendar className="inline h-4 w-4 mr-1" />
                  Pick-up Date
                </label>
                <input
                  type="date"
                  value={pickupDate}
                  onChange={(e) => setPickupDate(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <Calendar className="inline h-4 w-4 mr-1" />
                  Return Date
                </label>
                <input
                  type="date"
                  value={returnDate}
                  onChange={(e) => setReturnDate(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
            <div className="text-center mt-8">
              <Link
                to="/vehicles"
                className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg text-lg font-semibold transition-colors duration-200"
              >
                Search Vehicles
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Why Choose SwiftRide?</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              We make car rental simple, affordable, and reliable. Here's what sets us apart.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {benefits.map((benefit, index) => (
              <div key={index} className="text-center p-6 rounded-lg hover:shadow-lg transition-shadow duration-200">
                <div className="flex justify-center mb-4">
                  {benefit.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{benefit.title}</h3>
                <p className="text-gray-600">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Vehicles */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Featured Vehicles</h2>
            <p className="text-lg text-gray-600">Choose from our premium selection of vehicles</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                name: 'Toyota Corolla',
                type: 'Compact',
                price: 35,
                image: 'https://static0.carbuzzimages.com/wordpress/wp-content/uploads/2024/03/1156670-33.jpg',
                features: ['AC', 'Bluetooth', 'Backup Camera']
              },
              {
                name: 'Ford Escape',
                type: 'SUV',
                price: 55,
                image: 'https://hips.hearstapps.com/hmg-prod/images/2023-ford-escape-st-line-elite-rapid-red-01-1666667349.jpg?crop=0.755xw:0.644xh;0.109xw,0.204xh&resize=2048:*',
                features: ['AWD', 'Bluetooth', 'Roof Rails']
              },
              {
                name: 'BMW 3 Series',
                type: 'Luxury',
                price: 85,
                image: 'https://www.topgear.com/sites/default/files/2022/09/1-BMW-3-Series.jpg',
                features: ['Leather', 'Premium Sound', 'Sunroof']
              }
            ].map((vehicle, index) => (
              <div key={index} className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-200">
                <img src={vehicle.image} alt={vehicle.name} className="w-full h-48 object-cover" />
                <div className="p-6">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-xl font-semibold text-gray-900">{vehicle.name}</h3>
                    <span className="text-sm font-medium text-blue-600 bg-blue-100 px-2 py-1 rounded">
                      {vehicle.type}
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {vehicle.features.map((feature, featureIndex) => (
                      <span key={featureIndex} className="text-xs text-gray-600 bg-gray-100 px-2 py-1 rounded">
                        {feature}
                      </span>
                    ))}
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <div>
                      <span className="text-2xl font-bold text-gray-900">${vehicle.price}</span>
                      <span className="text-sm text-gray-600">/day</span>
                    </div>
                    <Link
                      to="/vehicles"
                      className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-semibold transition-colors duration-200"
                    >
                      Book Now
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="text-center mt-12">
            <Link
              to="/vehicles"
              className="bg-gray-900 hover:bg-gray-800 text-white px-8 py-3 rounded-lg text-lg font-semibold transition-colors duration-200"
            >
              View All Vehicles
            </Link>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">What Our Customers Say</h2>
            <p className="text-lg text-gray-600">Don't just take our word for it</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-gray-50 p-6 rounded-lg">
                <div className="flex items-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-700 mb-4 italic">"{testimonial.comment}"</p>
                <div>
                  <p className="font-semibold text-gray-900">{testimonial.name}</p>
                  <p className="text-sm text-gray-600">{testimonial.location}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Hit the Road?</h2>
          <p className="text-xl mb-8 opacity-90">
            Book your perfect rental car today and experience the freedom of the open road.
          </p>
          
          <Link
            to="/vehicles"
            className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-3 rounded-lg text-lg font-semibold transition-colors duration-200"
          >
            Start Your Journey
          </Link>
        </div>
      </section>
    </div>
  );
};

export default HomePage;