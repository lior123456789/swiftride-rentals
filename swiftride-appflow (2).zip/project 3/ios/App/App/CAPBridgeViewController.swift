import UIKit
import Capacitor

class CAPBridgeViewController: CAPBridgeViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Configure the bridge
        setupBridge()
        
        // Set background color
        view.backgroundColor = UIColor.white
        
        // Configure status bar
        setNeedsStatusBarAppearanceUpdate()
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    override var prefersStatusBarHidden: Bool {
        return false
    }
    
    private func setupBridge() {
        // Add any custom bridge configuration here
        bridge?.webView?.scrollView.contentInsetAdjustmentBehavior = .automatic
        bridge?.webView?.scrollView.bounces = false
        
        // Disable zoom
        bridge?.webView?.scrollView.maximumZoomScale = 1.0
        bridge?.webView?.scrollView.minimumZoomScale = 1.0
        
        // Configure web view settings
        bridge?.webView?.configuration.allowsInlineMediaPlayback = true
        bridge?.webView?.configuration.mediaTypesRequiringUserActionForPlayback = []
        
        // Handle safe area
        if #available(iOS 11.0, *) {
            bridge?.webView?.scrollView.contentInsetAdjustmentBehavior = .automatic
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        // Ensure proper layout
        view.setNeedsLayout()
        view.layoutIfNeeded()
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        
        coordinator.animate(alongsideTransition: { _ in
            // Handle rotation
            self.view.setNeedsLayout()
        }, completion: nil)
    }
}