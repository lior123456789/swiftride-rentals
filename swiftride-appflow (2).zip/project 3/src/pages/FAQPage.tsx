import React, { useState } from 'react';
import { ChevronDown, ChevronUp, Search } from 'lucide-react';

interface FAQ {
  id: number;
  question: string;
  answer: string;
  category: string;
}

const FAQPage: React.FC = () => {
  const [openFAQ, setOpenFAQ] = useState<number | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const faqs: FAQ[] = [
    {
      id: 1,
      question: "What are the requirements to rent a car?",
      answer: "You must be at least 21 years old, have a valid driver's license held for at least 1 year, and provide a major credit card in your name. International visitors need a valid passport and international driving permit.",
      category: "requirements"
    },
    {
      id: 2,
      question: "What is the minimum age to rent a car?",
      answer: "The minimum age to rent a car is 21 years old. Drivers aged 21-24 may be subject to additional fees and restrictions on certain vehicle categories.",
      category: "requirements"
    },
    {
      id: 3,
      question: "Do you offer insurance coverage?",
      answer: "Yes, we offer comprehensive insurance options including collision damage waiver, liability protection, and personal accident insurance. Check with your personal auto insurance and credit card company as they may provide coverage for rental cars.",
      category: "insurance"
    },
    {
      id: 4,
      question: "What is your cancellation policy?",
      answer: "You can cancel your reservation up to 24 hours before pickup without penalty. Cancellations within 24 hours may be subject to a fee. No-shows will be charged the full rental amount.",
      category: "booking"
    },
    {
      id: 5,
      question: "Can I add an additional driver?",
      answer: "Yes, additional drivers can be added for $10 per day. The additional driver must meet the same requirements as the primary renter and must be present during pickup to sign the rental agreement.",
      category: "requirements"
    },
    {
      id: 6,
      question: "What happens if the car breaks down?",
      answer: "If you experience a breakdown, call our 24/7 roadside assistance at 514-794-0471 immediately. We'll arrange for repairs or provide a replacement vehicle at no additional cost. Keep all receipts for any authorized repairs.",
      category: "support"
    },
    {
      id: 7,
      question: "Do you allow one-way rentals?",
      answer: "Yes, we offer one-way rentals between many of our locations. Additional fees may apply depending on the pickup and drop-off locations. Please check availability when making your reservation.",
      category: "booking"
    },
    {
      id: 8,
      question: "What fuel policy do you have?",
      answer: "We operate on a full-to-full fuel policy. You'll receive the car with a full tank and should return it with a full tank. If not returned full, you'll be charged for refueling at premium rates.",
      category: "policies"
    },
    {
      id: 9,
      question: "Are there any hidden fees?",
      answer: "No, we believe in transparent pricing. All fees are clearly disclosed during booking. This includes taxes, airport fees (if applicable), and any optional services you choose to add.",
      category: "pricing"
    },
    {
      id: 10,
      question: "Can I extend my rental period?",
      answer: "Yes, you can extend your rental period subject to vehicle availability. Contact us at least 24 hours before your scheduled return time. Extended rentals will be charged at the current daily rate.",
      category: "booking"
    },
    {
      id: 11,
      question: "What should I do if I'm in an accident?",
      answer: "First, ensure everyone's safety and call emergency services if needed. Then contact local police and our 24/7 support line at 514-794-0471. Take photos of the damage and get a police report number. Do not admit fault or sign any documents except the police report.",
      category: "support"
    },
    {
      id: 12,
      question: "Do you offer child seats?",
      answer: "Yes, we offer child seats for $12 per day. We have infant seats, convertible seats, and booster seats available. Due to safety regulations, we recommend you bring your own car seat or ensure proper installation.",
      category: "accessories"
    }
  ];

  const categories = [
    { value: 'all', label: 'All Categories' },
    { value: 'requirements', label: 'Requirements' },
    { value: 'booking', label: 'Booking' },
    { value: 'insurance', label: 'Insurance' },
    { value: 'policies', label: 'Policies' },
    { value: 'pricing', label: 'Pricing' },
    { value: 'support', label: 'Support' },
    { value: 'accessories', label: 'Accessories' }
  ];

  const filteredFAQs = faqs.filter(faq => {
    const matchesSearch = faq.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         faq.answer.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || faq.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const toggleFAQ = (id: number) => {
    setOpenFAQ(openFAQ === id ? null : id);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <section className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Frequently Asked Questions</h1>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Find answers to common questions about our car rental services
            </p>
          </div>
        </div>
      </section>

      {/* Search and Filter */}
      <section className="py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row gap-4 mb-8">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <input
                type="text"
                placeholder="Search FAQs..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {categories.map(category => (
                <option key={category.value} value={category.value}>
                  {category.label}
                </option>
              ))}
            </select>
          </div>
        </div>
      </section>

      {/* FAQ List */}
      <section className="pb-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-lg shadow-sm">
            {filteredFAQs.length === 0 ? (
              <div className="p-8 text-center">
                <div className="text-gray-400 mb-4">
                  <svg className="h-12 w-12 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">No FAQs found</h3>
                <p className="text-gray-600">Try adjusting your search or filter to find what you're looking for.</p>
              </div>
            ) : (
              <div className="divide-y divide-gray-200">
                {filteredFAQs.map((faq) => (
                  <div key={faq.id} className="p-6">
                    <button
                      onClick={() => toggleFAQ(faq.id)}
                      className="w-full flex justify-between items-center text-left focus:outline-none"
                    >
                      <h3 className="text-lg font-medium text-gray-900 pr-4">
                        {faq.question}
                      </h3>
                      {openFAQ === faq.id ? (
                        <ChevronUp className="h-5 w-5 text-gray-500 flex-shrink-0" />
                      ) : (
                        <ChevronDown className="h-5 w-5 text-gray-500 flex-shrink-0" />
                      )}
                    </button>
                    {openFAQ === faq.id && (
                      <div className="mt-4 pr-12">
                        <p className="text-gray-600 leading-relaxed">{faq.answer}</p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Contact Support */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">Still Have Questions?</h2>
          <p className="text-xl opacity-90 mb-8">
            Our customer support team is here to help you 24/7
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="/contact"
              className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-3 rounded-lg text-lg font-semibold transition-colors duration-200"
            >
              Contact Support
            </a>
            <a
              href="tel:514-794-0471"
              className="bg-transparent border-2 border-white hover:bg-white hover:text-blue-600 text-white px-8 py-3 rounded-lg text-lg font-semibold transition-all duration-200"
            >
              Call 514-794-0471
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default FAQPage;