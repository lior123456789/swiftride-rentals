import React, { useState } from 'react';
import { Car, Plus, Edit, Trash2, Save, X } from 'lucide-react';
import { cars, Car as CarType } from '../data/cars';
import ImageUpload from '../components/ImageUpload';

const AdminPage: React.FC = () => {
  const [carList, setCarList] = useState<CarType[]>(cars);
  const [editingCar, setEditingCar] = useState<CarType | null>(null);
  const [isAddingNew, setIsAddingNew] = useState(false);

  const [newCar, setNewCar] = useState<Partial<CarType>>({
    make: '',
    model: '',
    year: new Date().getFullYear(),
    type: 'compact',
    transmission: 'automatic',
    fuelType: 'gasoline',
    passengers: 5,
    luggage: 2,
    features: [],
    pricePerDay: 0,
    imageUrl: '',
    company: 'Hertz',
    available: true,
    rating: 4.5
  });

  const handleImageUpload = (url: string, carId?: string) => {
    if (carId) {
      // Update existing car
      setCarList(prev => prev.map(car => 
        car.id === carId ? { ...car, imageUrl: url } : car
      ));
    } else {
      // Update new car
      setNewCar(prev => ({ ...prev, imageUrl: url }));
    }
  };

  const handleSaveNewCar = () => {
    if (newCar.make && newCar.model && newCar.imageUrl) {
      const car: CarType = {
        ...newCar as CarType,
        id: Date.now().toString(),
        features: newCar.features || []
      };
      
      setCarList(prev => [...prev, car]);
      setNewCar({
        make: '',
        model: '',
        year: new Date().getFullYear(),
        type: 'compact',
        transmission: 'automatic',
        fuelType: 'gasoline',
        passengers: 5,
        luggage: 2,
        features: [],
        pricePerDay: 0,
        imageUrl: '',
        company: 'Hertz',
        available: true,
        rating: 4.5
      });
      setIsAddingNew(false);
    }
  };

  const handleDeleteCar = (carId: string) => {
    if (confirm('Are you sure you want to delete this car?')) {
      setCarList(prev => prev.filter(car => car.id !== carId));
    }
  };

  const exportCarData = () => {
    const dataStr = JSON.stringify(carList, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'cars-data.json';
    link.click();
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Car Management</h1>
              <p className="text-gray-600 mt-2">Manage your vehicle fleet and images</p>
            </div>
            <div className="flex gap-4">
              <button
                onClick={exportCarData}
                className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors"
              >
                Export Data
              </button>
              <button
                onClick={() => setIsAddingNew(true)}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
              >
                <Plus className="h-4 w-4" />
                Add New Car
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Add New Car Form */}
        {isAddingNew && (
          <div className="bg-white p-6 rounded-lg shadow-sm mb-8">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-semibold text-gray-900">Add New Car</h2>
              <button
                onClick={() => setIsAddingNew(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Make</label>
                  <input
                    type="text"
                    value={newCar.make}
                    onChange={(e) => setNewCar(prev => ({ ...prev, make: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Model</label>
                  <input
                    type="text"
                    value={newCar.model}
                    onChange={(e) => setNewCar(prev => ({ ...prev, model: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Price per Day ($)</label>
                  <input
                    type="number"
                    value={newCar.pricePerDay}
                    onChange={(e) => setNewCar(prev => ({ ...prev, pricePerDay: parseInt(e.target.value) }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Car Image</label>
                <ImageUpload
                  onImageUploaded={(url) => handleImageUpload(url)}
                  currentImage={newCar.imageUrl}
                />
              </div>
            </div>
            
            <div className="flex justify-end gap-4 mt-6">
              <button
                onClick={() => setIsAddingNew(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveNewCar}
                disabled={!newCar.make || !newCar.model || !newCar.imageUrl}
                className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
              >
                <Save className="h-4 w-4" />
                Save Car
              </button>
            </div>
          </div>
        )}

        {/* Car List */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {carList.map((car) => (
            <div key={car.id} className="bg-white rounded-lg shadow-sm overflow-hidden">
              <div className="relative">
                <img 
                  src={car.imageUrl} 
                  alt={`${car.make} ${car.model}`}
                  className="w-full h-48 object-cover"
                />
                <div className="absolute top-2 right-2 flex gap-2">
                  <button
                    onClick={() => setEditingCar(car)}
                    className="bg-blue-600 hover:bg-blue-700 text-white p-2 rounded-full transition-colors"
                  >
                    <Edit className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => handleDeleteCar(car.id)}
                    className="bg-red-600 hover:bg-red-700 text-white p-2 rounded-full transition-colors"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
              
              <div className="p-4">
                <h3 className="text-lg font-semibold text-gray-900">{car.make} {car.model}</h3>
                <p className="text-gray-600">{car.year} • {car.company}</p>
                <div className="flex justify-between items-center mt-2">
                  <span className="text-xl font-bold text-blue-600">${car.pricePerDay}/day</span>
                  <span className={`px-2 py-1 rounded-full text-xs ${
                    car.available ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                  }`}>
                    {car.available ? 'Available' : 'Unavailable'}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Edit Modal */}
        {editingCar && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-lg p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold text-gray-900">Edit Car Image</h2>
                <button
                  onClick={() => setEditingCar(null)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>
              
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    {editingCar.make} {editingCar.model}
                  </h3>
                  <p className="text-gray-600 mb-4">Upload a new image for this vehicle</p>
                </div>
                
                <ImageUpload
                  onImageUploaded={(url) => handleImageUpload(url, editingCar.id)}
                  currentImage={editingCar.imageUrl}
                />
              </div>
              
              <div className="flex justify-end gap-4 mt-6">
                <button
                  onClick={() => setEditingCar(null)}
                  className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminPage;