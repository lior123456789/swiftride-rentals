import React, { useState, useEffect } from 'react';
import { User, Calendar, CreditCard, FileText, Settings, Download, Star, Shield, Car, MapPin, Clock } from 'lucide-react';
import { useAuth } from '../components/AuthProvider';
import { useSubscription } from '../hooks/useSubscription';
import { useBookings, Booking } from '../hooks/useBookings';
import StripeProductCard from '../components/StripeProductCard';
import BookingDetailsModal from '../components/BookingDetailsModal';
import ReceiptModal from '../components/ReceiptModal';
import { getMainDownPaymentProduct } from '../stripe-config';
import { useSearchParams } from 'react-router-dom';

const AccountPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const initialTab = searchParams.get('tab') || 'overview';
  const paymentAction = searchParams.get('action');
  
  const [activeTab, setActiveTab] = useState(initialTab);
  const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
  const [isReceiptModalOpen, setIsReceiptModalOpen] = useState(false);
  
  const { user } = useAuth();
  const { subscription, orders, loading: subscriptionLoading, hasDownPayment, refetch } = useSubscription();
  const { bookings, loading: bookingsLoading, updateBookingStatus } = useBookings();

  // Get the main down payment product
  const downPaymentProduct = getMainDownPaymentProduct();

  // Auto-focus on payment if action=payment
  useEffect(() => {
    if (paymentAction === 'payment' && !hasDownPayment()) {
      setActiveTab('overview');
      // Scroll to down payment section
      setTimeout(() => {
        const paymentSection = document.getElementById('down-payment-section');
        if (paymentSection) {
          paymentSection.scrollIntoView({ behavior: 'smooth' });
        }
      }, 100);
    }
  }, [paymentAction, hasDownPayment]);

  // Refetch subscription data when component mounts or user changes
  useEffect(() => {
    if (user) {
      refetch();
    }
  }, [user, refetch]);

  const tabs = [
    { id: 'overview', name: 'Overview', icon: <User className="h-5 w-5" /> },
    { id: 'bookings', name: 'My Bookings', icon: <Calendar className="h-5 w-5" /> },
    { id: 'billing', name: 'Billing', icon: <CreditCard className="h-5 w-5" /> },
    { id: 'documents', name: 'Documents', icon: <FileText className="h-5 w-5" /> },
    { id: 'settings', name: 'Settings', icon: <Settings className="h-5 w-5" /> }
  ];

  const getSubscriptionStatus = () => {
    if (subscriptionLoading) return 'Loading...';
    if (!subscription) return 'No active subscription';
    
    switch (subscription.subscription_status) {
      case 'active':
        return 'Active Subscription';
      case 'trialing':
        return 'Trial Period';
      case 'past_due':
        return 'Payment Past Due';
      case 'canceled':
        return 'Canceled';
      case 'not_started':
        return 'No Subscription';
      default:
        return subscription.subscription_status;
    }
  };

  const getStatusColor = (status: Booking['status']) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'confirmed':
        return 'bg-blue-100 text-blue-800';
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'completed':
        return 'bg-gray-100 text-gray-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getPaymentStatusColor = (status: Booking['payment_status']) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'down_payment_paid':
        return 'bg-blue-100 text-blue-800';
      case 'fully_paid':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const formatTime = (timeString: string) => {
    return new Date(`2000-01-01T${timeString}`).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  const handleViewDetails = (booking: Booking) => {
    setSelectedBooking(booking);
    setIsDetailsModalOpen(true);
  };

  const handleViewReceipt = (booking: Booking) => {
    setSelectedBooking(booking);
    setIsReceiptModalOpen(true);
  };

  const TabContent = () => {
    switch (activeTab) {
      case 'overview':
        return (
          <div className="space-y-6">
            {/* Payment Required Alert */}
            {!hasDownPayment() && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-6">
                <div className="flex items-start">
                  <Shield className="h-6 w-6 text-red-600 mt-0.5 mr-3 flex-shrink-0" />
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-red-900 mb-2">
                      Action Required: Complete Down Payment
                    </h3>
                    <p className="text-red-800 mb-4">
                      You must complete a {downPaymentProduct.currency} ${downPaymentProduct.price.toFixed(2)} down payment before you can book any car rentals. 
                      This payment is required for all bookings and will be deducted from your final rental cost.
                    </p>
                    <div className="bg-red-100 border border-red-300 rounded-lg p-3">
                      <p className="text-sm text-red-800 font-medium">
                        ⚠️ All booking attempts will be blocked until this payment is completed.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Payment Complete Alert */}
            {hasDownPayment() && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-6">
                <div className="flex items-start">
                  <Shield className="h-6 w-6 text-green-600 mt-0.5 mr-3 flex-shrink-0" />
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-green-900 mb-2">
                      ✅ Down Payment Complete!
                    </h3>
                    <p className="text-green-800 mb-2">
                      Your {downPaymentProduct.currency} ${downPaymentProduct.price.toFixed(2)} down payment has been processed successfully. 
                      You can now book any vehicle from our fleet.
                    </p>
                    <div className="bg-green-100 border border-green-300 rounded-lg p-3">
                      <p className="text-sm text-green-800 font-medium">
                        🚗 Ready to book! Browse our vehicles and start your rental journey.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-blue-50 p-6 rounded-lg">
                <h3 className="text-lg font-semibold text-blue-900 mb-2">Total Bookings</h3>
                <p className="text-3xl font-bold text-blue-600">{bookings.length}</p>
              </div>
              <div className="bg-green-50 p-6 rounded-lg">
                <h3 className="text-lg font-semibold text-green-900 mb-2">Total Spent</h3>
                <p className="text-3xl font-bold text-green-600">
                  ${bookings.reduce((sum, booking) => sum + booking.total_amount, 0).toFixed(2)}
                </p>
              </div>
              <div className="bg-purple-50 p-6 rounded-lg">
                <h3 className="text-lg font-semibold text-purple-900 mb-2">Down Payments</h3>
                <p className="text-3xl font-bold text-purple-600">{orders.length}</p>
                <p className="text-sm text-purple-700">completed</p>
              </div>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Bookings</h3>
              <div className="space-y-4">
                {bookings.length > 0 ? (
                  bookings.slice(0, 3).map((booking) => (
                    <div key={booking.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center">
                        <img 
                          src={booking.vehicle_image_url} 
                          alt={`${booking.vehicle_make} ${booking.vehicle_model}`}
                          className="w-16 h-12 object-cover rounded mr-4"
                        />
                        <div>
                          <p className="font-medium text-gray-900">
                            {booking.vehicle_make} {booking.vehicle_model} {booking.vehicle_year}
                          </p>
                          <p className="text-sm text-gray-600">
                            {formatDate(booking.pickup_date)} - {formatDate(booking.return_date)}
                          </p>
                          <p className="text-sm text-gray-600">ID: {booking.booking_id}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(booking.status)}`}>
                          {booking.status}
                        </span>
                        <p className="text-sm text-gray-600 mt-1">${booking.total_amount.toFixed(2)}</p>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8">
                    <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600">No bookings yet</p>
                    <p className="text-sm text-gray-500 mt-1">
                      {hasDownPayment() 
                        ? 'Start by browsing our vehicle fleet' 
                        : 'Complete your down payment to start booking'
                      }
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Down Payment Section */}
            <div id="down-payment-section" className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex items-center mb-4">
                <Shield className="h-6 w-6 text-blue-600 mr-2" />
                <h3 className="text-lg font-semibold text-gray-900">Rental Down Payment</h3>
                {hasDownPayment() && (
                  <span className="ml-auto bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
                    ✓ Completed
                  </span>
                )}
              </div>
              
              {hasDownPayment() ? (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <div className="flex items-center">
                    <Shield className="h-5 w-5 text-green-600 mr-2" />
                    <div>
                      <p className="text-sm font-medium text-green-900">Down Payment Complete</p>
                      <p className="text-xs text-green-700">
                        You have completed {orders.length} down payment(s). You can now book car rentals.
                      </p>
                    </div>
                  </div>
                  <div className="mt-3 pt-3 border-t border-green-200">
                    <p className="text-xs text-green-700">
                      <strong>Next steps:</strong> Visit our vehicle page to browse and book your rental car.
                    </p>
                  </div>
                </div>
              ) : (
                <div>
                  <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 mb-4">
                    <div className="flex items-start">
                      <Shield className="h-5 w-5 text-orange-600 mt-0.5 mr-2 flex-shrink-0" />
                      <div>
                        <p className="text-sm font-medium text-orange-900">Payment Required</p>
                        <p className="text-xs text-orange-700 mt-1">
                          This {downPaymentProduct.currency} ${downPaymentProduct.price.toFixed(2)} down payment is mandatory for all car rentals and will be applied to your final rental cost.
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="max-w-md">
                    <StripeProductCard 
                      product={downPaymentProduct} 
                      successUrl={`${window.location.origin}/success?redirect=${encodeURIComponent('/account?tab=overview')}`}
                      cancelUrl={window.location.href}
                    />
                  </div>
                </div>
              )}
            </div>
          </div>
        );

      case 'bookings':
        return (
          <div className="space-y-6">
            {/* Booking Restriction Notice */}
            {!hasDownPayment() && (
              <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                <div className="flex items-center">
                  <Shield className="h-5 w-5 text-orange-600 mr-2" />
                  <div>
                    <p className="text-sm font-medium text-orange-900">Booking Restricted</p>
                    <p className="text-xs text-orange-700">Complete your down payment to start making bookings.</p>
                  </div>
                </div>
              </div>
            )}

            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold text-gray-900">My Bookings</h3>
              <a
                href="/vehicles"
                className={`px-4 py-2 rounded-lg transition-colors ${
                  hasDownPayment() 
                    ? 'bg-blue-600 hover:bg-blue-700 text-white' 
                    : 'bg-gray-400 cursor-not-allowed text-white'
                }`}
                onClick={(e) => !hasDownPayment() && e.preventDefault()}
              >
                New Booking
              </a>
            </div>
            
            <div className="space-y-4">
              {bookingsLoading ? (
                <div className="text-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
                  <p className="text-gray-600">Loading bookings...</p>
                </div>
              ) : bookings.length > 0 ? (
                bookings.map((booking) => (
                  <div key={booking.id} className="bg-white p-6 rounded-lg shadow-sm border">
                    <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-4 mb-4">
                          <img 
                            src={booking.vehicle_image_url} 
                            alt={`${booking.vehicle_make} ${booking.vehicle_model}`}
                            className="w-20 h-16 object-cover rounded"
                          />
                          <div className="flex-1">
                            <div className="flex items-center gap-4 mb-2">
                              <h4 className="font-semibold text-gray-900">
                                {booking.vehicle_make} {booking.vehicle_model} {booking.vehicle_year}
                              </h4>
                              <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(booking.status)}`}>
                                {booking.status}
                              </span>
                              <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getPaymentStatusColor(booking.payment_status)}`}>
                                {booking.payment_status.replace('_', ' ')}
                              </span>
                            </div>
                            <p className="text-gray-600 mb-2">Booking ID: {booking.booking_id}</p>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-600">
                              <div className="flex items-center">
                                <MapPin className="h-4 w-4 mr-1" />
                                <span>Pickup: {booking.pickup_location}</span>
                              </div>
                              <div className="flex items-center">
                                <MapPin className="h-4 w-4 mr-1" />
                                <span>Return: {booking.dropoff_location}</span>
                              </div>
                              <div className="flex items-center">
                                <Calendar className="h-4 w-4 mr-1" />
                                <span>{formatDate(booking.pickup_date)} at {formatTime(booking.pickup_time)}</span>
                              </div>
                              <div className="flex items-center">
                                <Calendar className="h-4 w-4 mr-1" />
                                <span>{formatDate(booking.return_date)} at {formatTime(booking.return_time)}</span>
                              </div>
                            </div>
                            {booking.addons.length > 0 && (
                              <div className="mt-2">
                                <p className="text-sm text-gray-600">
                                  <strong>Add-ons:</strong> {booking.addons.join(', ')}
                                </p>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="mt-4 lg:mt-0 lg:text-right lg:ml-6">
                        <p className="text-lg font-semibold text-gray-900 mb-2">
                          ${booking.total_amount.toFixed(2)}
                        </p>
                        <p className="text-sm text-gray-600 mb-2">
                          {booking.rental_days} day{booking.rental_days > 1 ? 's' : ''} • {booking.vehicle_company}
                        </p>
                        <div className="flex flex-col sm:flex-row gap-2">
                          <button 
                            onClick={() => handleViewDetails(booking)}
                            className="bg-gray-100 hover:bg-gray-200 text-gray-700 px-3 py-1 rounded text-sm transition-colors"
                          >
                            View Details
                          </button>
                          <button 
                            onClick={() => handleViewReceipt(booking)}
                            className="bg-blue-100 hover:bg-blue-200 text-blue-700 px-3 py-1 rounded text-sm transition-colors"
                          >
                            <Download className="h-4 w-4 inline mr-1" />
                            Receipt
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-12">
                  <Car className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No bookings yet</h3>
                  <p className="text-gray-600 mb-6">
                    {hasDownPayment() 
                      ? 'Ready to book your first rental? Browse our vehicle fleet to get started.' 
                      : 'Complete your down payment to start booking car rentals.'
                    }
                  </p>
                  {hasDownPayment() && (
                    <a
                      href="/vehicles"
                      className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors duration-200"
                    >
                      Browse Vehicles
                    </a>
                  )}
                </div>
              )}
            </div>
          </div>
        );

      case 'billing':
        return (
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-gray-900">Billing Information</h3>
            
            {/* Payment History */}
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h4 className="font-semibold text-gray-900 mb-4">Down Payment History</h4>
              <div className="space-y-3">
                {orders.length > 0 ? (
                  orders.map((order) => (
                    <div key={order.order_id} className="flex justify-between items-center p-3 bg-gray-50 rounded">
                      <div>
                        <p className="font-medium text-gray-900">Car Rental Down Payment</p>
                        <p className="text-sm text-gray-600">{new Date(order.order_date).toLocaleDateString()}</p>
                        <p className="text-xs text-gray-500">Session: {order.checkout_session_id}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-medium text-gray-900">{order.currency.toUpperCase()} ${(order.amount_total / 100).toFixed(2)}</p>
                        <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                          order.payment_status === 'paid' 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-yellow-100 text-yellow-800'
                        }`}>
                          {order.payment_status}
                        </span>
                        <p className="text-xs text-gray-500 mt-1">Applied to rentals</p>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="p-4 border-2 border-dashed border-gray-300 rounded-lg text-center">
                    <CreditCard className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                    <p className="text-gray-600">No payment history</p>
                    <p className="text-sm text-gray-500 mt-1">Complete your first down payment to see history here</p>
                  </div>
                )}
              </div>
            </div>

            {/* Payment Methods */}
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h4 className="font-semibold text-gray-900 mb-4">Payment Methods</h4>
              <div className="space-y-4">
                {subscription?.payment_method_brand && subscription?.payment_method_last4 ? (
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center">
                      <CreditCard className="h-8 w-8 text-gray-400 mr-3" />
                      <div>
                        <p className="font-medium text-gray-900">
                          {subscription.payment_method_brand.toUpperCase()} **** {subscription.payment_method_last4}
                        </p>
                        <p className="text-sm text-gray-600">Used for down payments</p>
                      </div>
                    </div>
                    <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-sm">Primary</span>
                  </div>
                ) : (
                  <div className="p-4 border-2 border-dashed border-gray-300 rounded-lg text-center">
                    <CreditCard className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                    <p className="text-gray-600">No payment method on file</p>
                    <p className="text-sm text-gray-500 mt-1">Payment methods are saved when you complete your down payment</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        );

      case 'documents':
        return (
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-gray-900">Documents</h3>
            
            {/* Document Upload Restriction */}
            {!hasDownPayment() && (
              <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                <div className="flex items-center">
                  <Shield className="h-5 w-5 text-orange-600 mr-2" />
                  <div>
                    <p className="text-sm font-medium text-orange-900">Document Upload Restricted</p>
                    <p className="text-xs text-orange-700">Complete your down payment to upload documents.</p>
                  </div>
                </div>
              </div>
            )}
            
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h4 className="font-semibold text-gray-900 mb-4">Driver's License</h4>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 mb-2">Upload your driver's license</p>
                <button 
                  className={`px-4 py-2 rounded-lg transition-colors ${
                    hasDownPayment() 
                      ? 'bg-blue-600 hover:bg-blue-700 text-white' 
                      : 'bg-gray-400 cursor-not-allowed text-white'
                  }`}
                  disabled={!hasDownPayment()}
                >
                  Upload Document
                </button>
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h4 className="font-semibold text-gray-900 mb-4">Insurance Documents</h4>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 mb-2">Upload your insurance documents (optional)</p>
                <button 
                  className={`px-4 py-2 rounded-lg transition-colors ${
                    hasDownPayment() 
                      ? 'bg-gray-100 hover:bg-gray-200 text-gray-700' 
                      : 'bg-gray-400 cursor-not-allowed text-white'
                  }`}
                  disabled={!hasDownPayment()}
                >
                  Upload Document
                </button>
              </div>
            </div>
          </div>
        );

      case 'settings':
        return (
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-gray-900">Account Settings</h3>
            
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h4 className="font-semibold text-gray-900 mb-4">Personal Information</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                  <input 
                    type="email" 
                    value={user?.email || ''} 
                    disabled
                    className="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-50 text-gray-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">User ID</label>
                  <input 
                    type="text" 
                    value={user?.id || ''} 
                    disabled
                    className="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-50 text-gray-500 text-sm"
                  />
                </div>
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h4 className="font-semibold text-gray-900 mb-4">Preferences</h4>
              <div className="space-y-4">
                <label className="flex items-center">
                  <input type="checkbox" className="mr-2" defaultChecked />
                  <span className="text-gray-700">Email notifications for bookings</span>
                </label>
                <label className="flex items-center">
                  <input type="checkbox" className="mr-2" defaultChecked />
                  <span className="text-gray-700">SMS notifications for important updates</span>
                </label>
                <label className="flex items-center">
                  <input type="checkbox" className="mr-2" />
                  <span className="text-gray-700">Marketing emails and promotions</span>
                </label>
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h4 className="font-semibold text-gray-900 mb-4">Security</h4>
              <div className="space-y-4">
                <button className="w-full bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2 rounded-lg transition-colors text-left">
                  Change Password
                </button>
                <button className="w-full bg-gray-100 hover:bg-gray-200 text-gray-700 px-4 py-2 rounded-lg transition-colors text-left">
                  Enable Two-Factor Authentication
                </button>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Please sign in</h2>
          <p className="text-gray-600 mb-8">You need to be signed in to view your account.</p>
          <a
            href="/login"
            className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors duration-200"
          >
            Sign In
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <section className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-center">
            <div className="h-16 w-16 bg-blue-600 rounded-full flex items-center justify-center text-white text-xl font-bold mr-4">
              {user.email?.charAt(0).toUpperCase() || 'U'}
            </div>
            <div className="flex-1">
              <h1 className="text-2xl font-bold text-gray-900">{user.email}</h1>
              <p className="text-gray-600">Member since {new Date(user.created_at || '').toLocaleDateString()}</p>
            </div>
            
            {/* Payment Status Badge */}
            <div className="ml-4">
              {hasDownPayment() ? (
                <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
                  ✓ Payment Complete
                </span>
              ) : (
                <span className="bg-red-100 text-red-800 px-3 py-1 rounded-full text-sm font-medium">
                  ⚠️ Payment Required
                </span>
              )}
            </div>
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <div className="lg:w-64">
            <nav className="bg-white rounded-lg shadow-sm p-4">
              <ul className="space-y-2">
                {tabs.map((tab) => (
                  <li key={tab.id}>
                    <button
                      onClick={() => setActiveTab(tab.id)}
                      className={`w-full flex items-center px-3 py-2 text-left rounded-lg transition-colors ${
                        activeTab === tab.id
                          ? 'bg-blue-600 text-white'
                          : 'text-gray-700 hover:bg-gray-100'
                      }`}
                    >
                      {tab.icon}
                      <span className="ml-3">{tab.name}</span>
                      {tab.id === 'overview' && !hasDownPayment() && (
                        <span className="ml-auto w-2 h-2 bg-red-500 rounded-full"></span>
                      )}
                      {tab.id === 'bookings' && bookings.length > 0 && (
                        <span className="ml-auto bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs">
                          {bookings.length}
                        </span>
                      )}
                    </button>
                  </li>
                ))}
              </ul>
            </nav>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            <TabContent />
          </div>
        </div>
      </div>

      {/* Modals */}
      {selectedBooking && (
        <>
          <BookingDetailsModal
            booking={selectedBooking}
            isOpen={isDetailsModalOpen}
            onClose={() => {
              setIsDetailsModalOpen(false);
              setSelectedBooking(null);
            }}
          />
          <ReceiptModal
            booking={selectedBooking}
            isOpen={isReceiptModalOpen}
            onClose={() => {
              setIsReceiptModalOpen(false);
              setSelectedBooking(null);
            }}
          />
        </>
      )}
    </div>
  );
};

export default AccountPage;