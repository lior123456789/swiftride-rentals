export interface StripeProduct {
  id: string;
  priceId: string;
  name: string;
  description: string;
  mode: 'payment' | 'subscription';
  price: number;
  currency: string;
}

export const stripeProducts: StripeProduct[] = [
  {
    id: 'prod_SadI6b7Klt4Wzz',
    priceId: 'price_1RfS1SBbcfV4SRH8ENqB5Xt0',
    name: 'Down Payment',
    description: 'Down payment for the car rental and it will be deducted from the original cost of the total renting prices',
    mode: 'payment',
    price: 200.00,
    currency: 'CAD'
  }
];

export const getProductByPriceId = (priceId: string): StripeProduct | undefined => {
  return stripeProducts.find(product => product.priceId === priceId);
};

export const getProductById = (id: string): StripeProduct | undefined => {
  return stripeProducts.find(product => product.id === id);
};

// Get the main down payment product (now using $200 product only)
export const getMainDownPaymentProduct = (): StripeProduct => {
  return stripeProducts[0];
};

// Get the production product (same as main)
export const getProductionProduct = (): StripeProduct => {
  return stripeProducts[0];
};