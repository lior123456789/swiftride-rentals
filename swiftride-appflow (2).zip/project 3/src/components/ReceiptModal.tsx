import React from 'react';
import { X, Download, FileText, Calendar, MapPin, Car, User, CreditCard } from 'lucide-react';
import { Booking } from '../hooks/useBookings';

interface ReceiptModalProps {
  booking: Booking;
  isOpen: boolean;
  onClose: () => void;
}

const ReceiptModal: React.FC<ReceiptModalProps> = ({ booking, isOpen, onClose }) => {
  if (!isOpen) return null;

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const formatTime = (timeString: string) => {
    return new Date(`2000-01-01T${timeString}`).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  const handleDownloadReceipt = () => {
    // Create receipt content
    const receiptContent = `
SWIFTRIDE RENTALS - BOOKING RECEIPT
=====================================

Booking ID: ${booking.booking_id}
Date: ${new Date(booking.created_at).toLocaleDateString()}

CUSTOMER INFORMATION
--------------------
Name: ${booking.customer_first_name} ${booking.customer_last_name}
Email: ${booking.customer_email}
Phone: ${booking.customer_phone}

VEHICLE INFORMATION
-------------------
Vehicle: ${booking.vehicle_make} ${booking.vehicle_model} ${booking.vehicle_year}
Company: ${booking.vehicle_company}
Daily Rate: $${booking.daily_rate.toFixed(2)}

RENTAL DETAILS
--------------
Pickup: ${booking.pickup_location}
Date: ${formatDate(booking.pickup_date)} at ${formatTime(booking.pickup_time)}

Return: ${booking.dropoff_location}
Date: ${formatDate(booking.return_date)} at ${formatTime(booking.return_time)}

Rental Days: ${booking.rental_days}

PRICING BREAKDOWN
-----------------
Vehicle (${booking.rental_days} days): $${(booking.daily_rate * booking.rental_days).toFixed(2)}
${booking.addon_total > 0 ? `Add-ons: $${booking.addon_total.toFixed(2)}\n` : ''}Subtotal: $${booking.subtotal.toFixed(2)}
Tax: $${booking.tax_amount.toFixed(2)}
Total: $${booking.total_amount.toFixed(2)}
${booking.payment_status !== 'pending' ? `Down Payment: -$${booking.down_payment_amount.toFixed(2)}\n` : ''}
${booking.addons.length > 0 ? `\nADD-ONS\n-------\n${booking.addons.map(addon => `• ${addon}`).join('\n')}\n` : ''}
STATUS
------
Booking Status: ${booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
Payment Status: ${booking.payment_status.replace('_', ' ').charAt(0).toUpperCase() + booking.payment_status.replace('_', ' ').slice(1)}

Thank you for choosing SwiftRide Rentals!
For support, contact us at: 514-794-0471
    `;

    // Create and download the file
    const blob = new Blob([receiptContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `SwiftRide_Receipt_${booking.booking_id}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center">
            <FileText className="h-6 w-6 text-blue-600 mr-2" />
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Receipt</h2>
              <p className="text-gray-600">Booking ID: {booking.booking_id}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="p-6">
          {/* Company Header */}
          <div className="text-center mb-8">
            <div className="flex items-center justify-center mb-2">
              <Car className="h-8 w-8 text-blue-600 mr-2" />
              <h1 className="text-2xl font-bold text-gray-900">SwiftRide Rentals</h1>
            </div>
            <p className="text-gray-600">Premium Car Rental Services</p>
            <p className="text-sm text-gray-500">Phone: 514-794-0471 | Email: lior.amsellem@icloud.com</p>
          </div>

          {/* Receipt Details */}
          <div className="bg-gray-50 rounded-lg p-6 mb-6">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p><strong>Receipt Date:</strong></p>
                <p>{new Date().toLocaleDateString()}</p>
              </div>
              <div>
                <p><strong>Booking Date:</strong></p>
                <p>{new Date(booking.created_at).toLocaleDateString()}</p>
              </div>
            </div>
          </div>

          {/* Customer Information */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
              <User className="h-5 w-5 mr-2" />
              Customer Information
            </h3>
            <div className="bg-gray-50 rounded-lg p-4">
              <p><strong>Name:</strong> {booking.customer_first_name} {booking.customer_last_name}</p>
              <p><strong>Email:</strong> {booking.customer_email}</p>
              <p><strong>Phone:</strong> {booking.customer_phone}</p>
            </div>
          </div>

          {/* Vehicle Information */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
              <Car className="h-5 w-5 mr-2" />
              Vehicle Information
            </h3>
            <div className="bg-gray-50 rounded-lg p-4">
              <p><strong>Vehicle:</strong> {booking.vehicle_make} {booking.vehicle_model} {booking.vehicle_year}</p>
              <p><strong>Company:</strong> {booking.vehicle_company}</p>
              <p><strong>Daily Rate:</strong> ${booking.daily_rate.toFixed(2)}</p>
            </div>
          </div>

          {/* Rental Period */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
              <Calendar className="h-5 w-5 mr-2" />
              Rental Period
            </h3>
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <p><strong>Pickup:</strong></p>
                  <p>{booking.pickup_location}</p>
                  <p className="text-sm text-gray-600">{formatDate(booking.pickup_date)} at {formatTime(booking.pickup_time)}</p>
                </div>
                <div>
                  <p><strong>Return:</strong></p>
                  <p>{booking.dropoff_location}</p>
                  <p className="text-sm text-gray-600">{formatDate(booking.return_date)} at {formatTime(booking.return_time)}</p>
                </div>
              </div>
              <p className="mt-2"><strong>Total Days:</strong> {booking.rental_days}</p>
            </div>
          </div>

          {/* Add-ons */}
          {booking.addons.length > 0 && (
            <div className="mb-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Add-ons</h3>
              <div className="bg-gray-50 rounded-lg p-4">
                <ul className="space-y-1">
                  {booking.addons.map((addon, index) => (
                    <li key={index} className="text-gray-700">• {addon}</li>
                  ))}
                </ul>
              </div>
            </div>
          )}

          {/* Pricing Breakdown */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
              <CreditCard className="h-5 w-5 mr-2" />
              Pricing Breakdown
            </h3>
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Vehicle ({booking.rental_days} days)</span>
                  <span>${(booking.daily_rate * booking.rental_days).toFixed(2)}</span>
                </div>
                {booking.addon_total > 0 && (
                  <div className="flex justify-between">
                    <span>Add-ons</span>
                    <span>${booking.addon_total.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span>${booking.subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Tax</span>
                  <span>${booking.tax_amount.toFixed(2)}</span>
                </div>
                <div className="border-t pt-2 flex justify-between font-semibold text-lg">
                  <span>Total Amount</span>
                  <span>${booking.total_amount.toFixed(2)}</span>
                </div>
                {booking.payment_status !== 'pending' && (
                  <div className="flex justify-between text-green-600">
                    <span>Down Payment Applied</span>
                    <span>-${booking.down_payment_amount.toFixed(2)}</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Status */}
          <div className="mb-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-3">Status</h3>
            <div className="bg-gray-50 rounded-lg p-4">
              <p><strong>Booking Status:</strong> {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}</p>
              <p><strong>Payment Status:</strong> {booking.payment_status.replace('_', ' ').charAt(0).toUpperCase() + booking.payment_status.replace('_', ' ').slice(1)}</p>
            </div>
          </div>

          {/* Footer */}
          <div className="text-center text-sm text-gray-600 border-t pt-4">
            <p>Thank you for choosing SwiftRide Rentals!</p>
            <p>For support, contact us at: 514-794-0471</p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="border-t border-gray-200 px-6 py-4 bg-gray-50 rounded-b-lg">
          <div className="flex justify-between">
            <button
              onClick={handleDownloadReceipt}
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg font-medium transition-colors flex items-center"
            >
              <Download className="h-4 w-4 mr-2" />
              Download Receipt
            </button>
            <button
              onClick={onClose}
              className="bg-gray-600 hover:bg-gray-700 text-white px-6 py-2 rounded-lg font-medium transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReceiptModal;