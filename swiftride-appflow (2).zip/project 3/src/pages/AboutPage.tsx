import React from 'react';
import { Shield, Award, Users, Clock } from 'lucide-react';

const AboutPage: React.FC = () => {
  const stats = [
    { number: '50,000+', label: 'Happy Customers' },
    { number: '500+', label: 'Vehicles Available' },
    { number: '15+', label: 'Years Experience' },
    { number: '50+', label: 'Locations Nationwide' }
  ];

  const values = [
    {
      icon: <Shield className="h-8 w-8 text-blue-600" />,
      title: 'Safety First',
      description: 'All our vehicles undergo rigorous safety inspections and maintenance checks.'
    },
    {
      icon: <Award className="h-8 w-8 text-blue-600" />,
      title: 'Quality Service',
      description: 'We pride ourselves on delivering exceptional service and premium vehicles.'
    },
    {
      icon: <Users className="h-8 w-8 text-blue-600" />,
      title: 'Customer-Centric',
      description: 'Your satisfaction is our priority. We go above and beyond for every customer.'
    },
    {
      icon: <Clock className="h-8 w-8 text-blue-600" />,
      title: 'Always Available',
      description: '24/7 customer support and flexible rental options to fit your schedule.'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-r from-blue-900 to-blue-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">About SwiftRide Rentals</h1>
            <p className="text-xl md:text-2xl opacity-90 max-w-3xl mx-auto">
              Making mobility easy, reliable & affordable since 2009
            </p>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-blue-600 mb-2">{stat.number}</div>
                <div className="text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Story</h2>
              <div className="space-y-4 text-gray-600">
                <p>
                  SwiftRide Rentals was founded in 2009 by Lior Amsellem with a simple mission: to make car rental 
                  accessible, affordable, and hassle-free for everyone. What started as a small 
                  operation with just 10 vehicles has grown into a nationwide network serving 
                  thousands of customers daily.
                </p>
                <p>
                  Our founder, Lior Amsellem, experienced firsthand the frustrations of traditional 
                  car rental companies – hidden fees, poor customer service, and unreliable vehicles. 
                  He envisioned a better way, one that puts customers first and provides transparent, 
                  honest service.
                </p>
                <p>
                  Today, we're proud to be a trusted name in car rentals, known for our commitment 
                  to quality, safety, and customer satisfaction. Every vehicle in our fleet is 
                  carefully maintained and regularly inspected to ensure your safety and comfort.
                </p>
              </div>
            </div>
            <div>
              <img 
                src="https://images.pexels.com/photos/1592384/pexels-photo-1592384.jpeg?auto=compress&cs=tinysrgb&w=600" 
                alt="Our fleet" 
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Values</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              These core values guide everything we do and shape how we serve our customers
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <div key={index} className="text-center p-6 rounded-lg hover:shadow-lg transition-shadow duration-200">
                <div className="flex justify-center mb-4">
                  {value.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{value.title}</h3>
                <p className="text-gray-600">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Founder Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Meet Our Founder</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              The visionary behind SwiftRide who transformed the car rental experience
            </p>
          </div>
          <div className="max-w-4xl mx-auto">
            <div className="bg-white rounded-lg shadow-lg overflow-hidden">
              <div className="grid grid-cols-1 lg:grid-cols-2">
                <div className="relative">
                  <img 
                    src="https://images.pexels.com/photos/697509/pexels-photo-697509.jpeg?auto=compress&cs=tinysrgb&w=600" 
                    alt="Lior Amsellem" 
                    className="w-full h-64 lg:h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
                </div>
                <div className="p-8 flex flex-col justify-center">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">Lior Amsellem</h3>
                  <p className="text-blue-600 font-semibold mb-4">Founder & CEO</p>
                  <div className="space-y-4 text-gray-600">
                    <p>
                      With over 15 years of experience in the automotive and technology industries, 
                      Lior founded SwiftRide Rentals to revolutionize how people access reliable transportation.
                    </p>
                    <p>
                      His vision of combining cutting-edge technology with exceptional customer service 
                      has made SwiftRide a leader in the car rental industry, serving thousands of 
                      satisfied customers across the nation.
                    </p>
                    <p>
                      Under Lior's leadership, SwiftRide continues to innovate and expand, always 
                      keeping customer satisfaction and safety as the top priorities.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-6">Our Mission</h2>
          <p className="text-xl md:text-2xl opacity-90 max-w-4xl mx-auto leading-relaxed">
            "To provide reliable, affordable, and exceptional car rental services that empower 
            people to explore, connect, and achieve their goals with confidence and convenience."
          </p>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Ready to Experience the Difference?</h2>
          <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
            Join thousands of satisfied customers who choose SwiftRide for their car rental needs.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="/vehicles"
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg text-lg font-semibold transition-colors duration-200"
            >
              Browse Vehicles
            </a>
            <a
              href="/contact"
              className="bg-gray-100 hover:bg-gray-200 text-gray-900 px-8 py-3 rounded-lg text-lg font-semibold transition-colors duration-200"
            >
              Contact Us
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;